export function isUnauthorizedError(error: Error): boolean {
  return /^401: .*Unauthorized/.test(error.message);
}

export function getAuthHeaders(): HeadersInit {
  const employeeToken = localStorage.getItem('employee_token');
  const adminToken = localStorage.getItem('admin_token');
  const token = employeeToken || adminToken;
  return token ? { Authorization: `Bearer ${token}` } : {};
}
