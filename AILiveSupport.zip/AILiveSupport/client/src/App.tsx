import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import EmployeeDashboard from "@/pages/employee-dashboard";
import AdminDashboard from "@/pages/admin-dashboard";
import Login from "@/pages/login";
import EmployeeLoginForm from "@/components/employee-login-form";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading, isEmployee } = useAuth();
  const employeeToken = typeof window !== 'undefined' ? localStorage.getItem('employee_token') : null;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="text-4xl font-bold hyb-gradient-text hyb-logo">HYB</div>
          <div>Loading HYBEM...</div>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/employee-login" component={EmployeeLoginForm} />
      <Route path="/employee-dashboard">
        {isAuthenticated && isEmployee ? <EmployeeDashboard /> : <EmployeeLoginForm />}
      </Route>
      <Route path="/admin-dashboard">
        {isAuthenticated && !isEmployee ? <AdminDashboard /> : <Login />}
      </Route>
      <Route path="/">
        {!isAuthenticated ? (
          employeeToken ? <EmployeeLoginForm /> : <Login />
        ) : (
          isEmployee ? <EmployeeDashboard /> : <AdminDashboard />
        )}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
