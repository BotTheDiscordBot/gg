import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { useState, useEffect } from "react";
import { 
  Clock, 
  DollarSign, 
  MessageSquare, 
  Star, 
  Coffee, 
  Play, 
  Pause, 
  Search,
  Package,
  TrendingUp,
  Target,
  Award,
  LogOut
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import AnimatedChatQueue from "@/components/animated-chat-queue";
import ChatInterface from "@/components/chat-interface";
import MetricsGrid from "@/components/metrics-grid";
import AnimatedEarningsBreakdown from "@/components/animated-earnings-breakdown";
import { useWebSocket } from "@/hooks/useWebSocket";

export default function EmployeeDashboard() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [currentChat, setCurrentChat] = useState<number | null>(null);
  const [trackingNumber, setTrackingNumber] = useState("");
  const [trackingResult, setTrackingResult] = useState<any>(null);
  const [isTrackingDialogOpen, setIsTrackingDialogOpen] = useState(false);

  const { data: stats, isLoading: statsLoading } = useQuery<{
    todayEarnings: number;
    todayConversations: number;
    averageRating: number;
    totalEarnings: number;
  }>({
    queryKey: ['/api/employee/stats'],
  });

  const { data: currentSession } = useQuery<{
    id: number;
    employeeId: number;
    clockInTime: string;
    clockOutTime?: string;
    totalMinutes?: number;
    isOnBreak: boolean;
  }>({
    queryKey: ['/api/employee/current-session'],
    refetchInterval: 5000,
  });

  const clockInMutation = useMutation({
    mutationFn: () => apiRequest('/api/employee/clock-in', 'POST'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employee/current-session'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee/stats'] });
    },
    onError: (error) => {
      console.error('Clock in error:', error);
      alert('Clock in failed: ' + error.message);
    },
  });

  const clockOutMutation = useMutation({
    mutationFn: () => apiRequest('/api/employee/clock-out', 'POST'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employee/current-session'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee/stats'] });
    },
    onError: (error) => {
      console.error('Clock out error:', error);
      // Show error message to user
      alert('Clock out failed: ' + error.message);
    },
  });

  const toggleBreakMutation = useMutation({
    mutationFn: () => apiRequest('/api/employee/toggle-break', 'POST'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employee/current-session'] });
    },
  });

  const trackingLookupMutation = useMutation({
    mutationFn: async (orderNumber: string) => {
      const response = await apiRequest('/api/employee/tracking-lookup', 'POST', { orderNumber });
      return response.json();
    },
    onSuccess: (data) => {
      setTrackingResult(data);
    },
  });

  const handleTrackingLookup = () => {
    if (trackingNumber.trim()) {
      trackingLookupMutation.mutate(trackingNumber);
    }
  };

  const { sendMessage } = useWebSocket({
    onMessage: (message) => {
      if (message.type === 'conversation_assigned') {
        queryClient.invalidateQueries({ queryKey: ['/api/employee/active-chats'] });
      } else if (message.type === 'chat_ended') {
        // Auto-close chat when AI customer ends conversation
        if (message.conversationId === currentChat) {
          setCurrentChat(null);
          queryClient.invalidateQueries({ queryKey: ['/api/employee/queue'] });
          queryClient.invalidateQueries({ queryKey: ['/api/employee/stats'] });
          queryClient.invalidateQueries({ queryKey: ['/api/employee/earnings'] });
        }
      }
    },
  });

  const handlePickupChat = (conversationId: number) => {
    setCurrentChat(conversationId);
  };

  const handleCloseChat = () => {
    setCurrentChat(null);
    queryClient.invalidateQueries({ queryKey: ['/api/employee/queue'] });
    queryClient.invalidateQueries({ queryKey: ['/api/employee/stats'] });
  };

  const getStatusText = () => {
    if (!currentSession) return "Clocked Out";
    if (currentSession.isOnBreak) return "On Break";
    return "Active";
  };

  const getStatusColor = () => {
    if (!currentSession) return "secondary";
    if (currentSession.isOnBreak) return "destructive";
    return "default";
  };

  // If in a chat, show chat interface
  if (currentChat) {
    return (
      <ChatInterface
        conversationId={currentChat}
        onCloseChat={handleCloseChat}
        sendMessage={sendMessage}
      />
    );
  }

  return (
    <div className="min-h-screen p-6 space-y-6">
      {/* Header */}
      <div className="glass-card rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="text-3xl font-bold hyb-gradient-text hyb-logo">HYB</div>
            <div>
              <h1 className="text-2xl font-bold">
                Welcome, {user?.firstName} {user?.lastName}
              </h1>
              <p className="text-muted-foreground">HYBEM Employee Dashboard</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant={getStatusColor() as any} className="status-pulse">
              {getStatusText()}
            </Badge>
            <div className="text-xs text-muted-foreground">
              Powered by jahceere
            </div>
            <Button
              onClick={() => {
                localStorage.removeItem('employee_token');
                window.location.href = '/';
              }}
              variant="outline"
              size="sm"
              className="glass-button"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Time Management */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5" />
            <span>Time Management</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              {currentSession ? (
                <>
                  <div className="text-sm text-muted-foreground">
                    Clocked in at: {new Date(currentSession.clockInTime).toLocaleTimeString()}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={currentSession.isOnBreak ? "destructive" : "default"}>
                      {currentSession.isOnBreak ? "On Break" : "Active"}
                    </Badge>
                  </div>
                </>
              ) : (
                <div className="text-sm text-muted-foreground">
                  You are currently clocked out
                </div>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {!currentSession ? (
                <Button
                  onClick={() => clockInMutation.mutate()}
                  disabled={clockInMutation.isPending}
                  className="glass-button"
                >
                  <Play className="h-4 w-4 mr-2" />
                  Clock In
                </Button>
              ) : (
                <>
                  <Button
                    onClick={() => toggleBreakMutation.mutate()}
                    disabled={toggleBreakMutation.isPending}
                    variant={currentSession.isOnBreak ? "default" : "outline"}
                    className="glass-button"
                  >
                    <Coffee className="h-4 w-4 mr-2" />
                    {currentSession.isOnBreak ? "End Break" : "Take Break"}
                  </Button>
                  <Button
                    onClick={() => clockOutMutation.mutate()}
                    disabled={clockOutMutation.isPending}
                    variant="destructive"
                    className="glass-button"
                  >
                    <Pause className="h-4 w-4 mr-2" />
                    Clock Out
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Animated Stats */}
      <MetricsGrid stats={stats} isLoading={statsLoading} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chat Queue */}
        <AnimatedChatQueue 
          onPickupChat={handlePickupChat} 
          disabled={!currentSession || currentSession.isOnBreak}
        />

        {/* Customer Tools */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-5 w-5" />
              <span>Customer Tools</span>
            </CardTitle>
            <CardDescription>
              Tools to help customers with their HostYourBot orders
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Dialog open={isTrackingDialogOpen} onOpenChange={setIsTrackingDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full glass-button">
                  <Search className="h-4 w-4 mr-2" />
                  Order Lookup Tool
                </Button>
              </DialogTrigger>
              <DialogContent className="glass-card">
                <DialogHeader>
                  <DialogTitle>Customer Order Lookup</DialogTitle>
                  <DialogDescription>
                    Look up order details to help customers with their inquiries
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Enter order number (e.g., HYB-2024-1847)"
                      value={trackingNumber}
                      onChange={(e) => setTrackingNumber(e.target.value)}
                      className="bg-input/50"
                    />
                    <Button 
                      onClick={handleTrackingLookup}
                      disabled={trackingLookupMutation.isPending}
                      className="glass-button"
                    >
                      {trackingLookupMutation.isPending ? 'Looking up...' : 'Lookup'}
                    </Button>
                  </div>
                  
                  {trackingResult && (
                    <div className="space-y-4 p-4 rounded-lg bg-secondary/20 border border-white/10">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">Order {trackingResult.orderNumber}</h3>
                        <Badge className="tracking-status">
                          {trackingResult.status.replace(/_/g, ' ').toUpperCase()}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="text-muted-foreground">Service Type</div>
                          <div className="capitalize">{trackingResult.serviceType.replace(/_/g, ' ')}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Tracking ID</div>
                          <div className="font-mono">{trackingResult.trackingId}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Order Date</div>
                          <div>{new Date(trackingResult.orderDate).toLocaleDateString()}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Customer</div>
                          <div>{trackingResult.customerEmail}</div>
                        </div>
                      </div>
                      
                      {trackingResult.notes && (
                        <div>
                          <div className="text-muted-foreground text-sm">Notes</div>
                          <div className="text-sm">{trackingResult.notes}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      </div>

      {/* Animated Earnings Breakdown */}
      <AnimatedEarningsBreakdown />
    </div>
  );
}