import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Eye, EyeOff, LogIn, Shield, Users, Settings } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

type LoginData = z.infer<typeof loginSchema>;

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [loginType, setLoginType] = useState<'employee' | 'admin'>('employee');
  const { toast } = useToast();

  const form = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginData) => {
      const endpoint = loginType === 'admin' ? '/api/login' : '/api/employee/login';
      const response = await fetch(endpoint, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: Login failed`);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      if (loginType === 'employee') {
        localStorage.removeItem('admin_token');
        localStorage.setItem('employee_token', data.token);
        window.location.href = '/employee-dashboard';
      } else {
        localStorage.removeItem('employee_token');
        localStorage.setItem('admin_token', data.token);
        window.location.href = '/admin-dashboard';
      }
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Login Failed",
          description: "Invalid email or password. Please try again.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Login Error",
          description: "An error occurred during login. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const onSubmit = (data: LoginData) => {
    loginMutation.mutate(data);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="text-5xl font-bold hyb-gradient-text hyb-logo">HYB</div>
          <div>
            <h1 className="text-3xl font-bold">HYBEM</h1>
            <p className="text-muted-foreground">Host Your Bot Employee Management</p>
          </div>
        </div>

        {/* Login Type Selector */}
        <div className="flex space-x-2">
          <Button
            type="button"
            variant={loginType === 'employee' ? 'default' : 'outline'}
            onClick={() => setLoginType('employee')}
            className="flex-1 glass-button"
          >
            <Users className="h-4 w-4 mr-2" />
            Employee
          </Button>
          <Button
            type="button"
            variant={loginType === 'admin' ? 'default' : 'outline'}
            onClick={() => setLoginType('admin')}
            className="flex-1 glass-button"
          >
            <Shield className="h-4 w-4 mr-2" />
            Admin
          </Button>
        </div>

        {/* Login Form */}
        <Card className="glass-card">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">
              {loginType === 'admin' ? 'Admin Login' : 'Employee Login'}
            </CardTitle>
            <CardDescription className="text-center">
              {loginType === 'admin' 
                ? 'Access the administrative dashboard' 
                : 'Access your employee dashboard and start earning'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="email"
                          placeholder="Enter your @hostyourbot.com email"
                          className="bg-input/50 backdrop-blur-sm"
                          autoComplete="email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            {...field}
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your password"
                            className="bg-input/50 backdrop-blur-sm pr-10"
                            autoComplete="current-password"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full glass-button"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? (
                    "Signing in..."
                  ) : (
                    <>
                      <LogIn className="h-4 w-4 mr-2" />
                      Sign In
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>



        {/* Footer */}
        <div className="text-center space-y-2">
          <div className="text-xs text-muted-foreground">
            Powered by jahceere • HostYourBot.com
          </div>
          <Badge variant="outline" className="text-xs">
            Professional Training Platform
          </Badge>
        </div>
      </div>
    </div>
  );
}