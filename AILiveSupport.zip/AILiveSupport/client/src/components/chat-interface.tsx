import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { X, Send, User, Share, Pause, Play } from "lucide-react";
import { format } from "date-fns";

interface ChatInterfaceProps {
  conversationId: number;
  onCloseChat: () => void;
  sendMessage: (data: any) => void;
}

export default function ChatInterface({ conversationId, onCloseChat, sendMessage }: ChatInterfaceProps) {
  const [messageText, setMessageText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isOnHold, setIsOnHold] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch conversation details
  const { data: conversation, error, isLoading } = useQuery<{
    id: number;
    employeeId: number;
    aiCustomerId: number;
    chatNumber: string;
    status: string;
    startedAt: string;
    aiCustomer: {
      id: number;
      name: string;
      email: string;
      location: string;
      customerType: string;
      personalityType: string;
      avgRating: string | null;
      serviceType: string;
      orderNumber: string;
      trackingStatus: string;
    };
  }>({
    queryKey: [`/api/conversation/${conversationId}`],
    enabled: !!conversationId,
  });

  // Fetch messages
  const { data: messages } = useQuery<Array<{
    id: number;
    conversationId: number;
    senderType: string;
    content: string;
    timestamp: string;
  }>>({
    queryKey: [`/api/conversation/${conversationId}/messages`],
    enabled: !!conversationId,
    refetchInterval: 2000, // Poll for new messages
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Simulate typing indicator
  useEffect(() => {
    if (messages && Array.isArray(messages) && messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage && lastMessage.senderType === 'employee') {
        setIsTyping(true);
        const timer = setTimeout(() => setIsTyping(false), Math.random() * 3000 + 2000);
        return () => clearTimeout(timer);
      }
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!messageText.trim()) return;

    sendMessage({
      type: 'send_message',
      conversationId,
      content: messageText.trim(),
    });

    setMessageText("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!conversation) {
    return (
      <div className="w-96 bg-white border-l border-gray-200 flex items-center justify-center">
        <div className="text-center text-gray-500">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-300 mx-auto mb-2"></div>
          Loading chat...
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-white border-l border-gray-200 flex flex-col min-w-0">
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200 bg-gray-50 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="w-8 h-8">
              <AvatarFallback>
                <User className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-gray-900">{conversation?.aiCustomer?.name || "No Name Provided"}</p>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full status-pulse ${isOnHold ? 'bg-yellow-500' : 'bg-green-500'}`} />
                <span className="text-xs text-gray-500">{isOnHold ? 'On Hold' : 'Online'}</span>
                {conversation?.aiCustomer?.name && conversation.aiCustomer.name !== "No Name Provided" && (
                  <Badge variant="outline" className="text-xs">
                    {conversation?.aiCustomer?.customerType}
                  </Badge>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant={isOnHold ? "default" : "outline"}
              size="sm"
              onClick={() => setIsOnHold(!isOnHold)}
              className="text-xs"
            >
              {isOnHold ? <Play className="w-3 h-3 mr-1" /> : <Pause className="w-3 h-3 mr-1" />}
              {isOnHold ? 'Resume' : 'Hold'}
            </Button>
            <span className="text-xs text-gray-500">{conversation?.chatNumber}</span>
            <Button variant="ghost" size="sm" onClick={onCloseChat}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Customer Info */}
      <div className="p-3 bg-blue-50 border-b border-gray-200">
        <div className="text-xs text-gray-600">
          <p><strong>Location:</strong> {conversation?.aiCustomer?.location}</p>
          {conversation?.aiCustomer?.avgRating && conversation?.aiCustomer?.name !== "No Name Provided" && (
            <p><strong>Avg Rating:</strong> {conversation.aiCustomer.avgRating}/5.0</p>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto bg-gray-50 chat-scroll">
        <div className="space-y-4">
          {messages && Array.isArray(messages) && messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.senderType === 'system' ? 'justify-center' :
                message.senderType === 'employee' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div className={`max-w-xs ${message.senderType === 'system' ? 'max-w-full' : ''}`}>
                <div
                  className={`rounded-lg px-4 py-2 ${
                    message.senderType === 'system'
                      ? 'bg-gray-100 text-gray-600 text-center italic text-xs'
                      : message.senderType === 'employee'
                      ? 'bg-primary text-white'
                      : 'bg-white border border-gray-200 text-gray-900'
                  }`}
                >
                  <p className={`${message.senderType === 'system' ? 'text-xs' : 'text-sm'}`}>
                    {message.content}
                  </p>
                </div>
                {message.senderType !== 'system' && (
                  <p className={`text-xs text-gray-500 mt-1 ${
                    message.senderType === 'employee' ? 'text-right' : 'text-left'
                  }`}>
                    {format(new Date(message.timestamp), 'h:mm a')}
                  </p>
                )}
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex justify-start">
              <div className="max-w-xs">
                <div className="bg-white rounded-lg px-4 py-3 border border-gray-200">
                  <div className="typing-indicator">
                    <div className="typing-dot"></div>
                    <div className="typing-dot"></div>
                    <div className="typing-dot"></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Message Input */}
      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="flex items-end space-x-2">
          <Textarea
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Type your response..."
            className="flex-1 resize-none min-h-0"
            rows={2}
          />
          <Button onClick={handleSendMessage} disabled={!messageText.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="flex items-center justify-end mt-2">
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
              <User className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
              <Share className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
