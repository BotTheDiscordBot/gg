import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { DollarSign, MessageSquare, Star, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";

interface Earning {
  id: number;
  amount: number;
  conversationId: number;
  earnedAt: string;
  conversation?: {
    id: number;
    customerRating: number;
    aiCustomerId: number;
  };
}

export default function AnimatedEarningsBreakdown() {
  const { data: earnings, isLoading } = useQuery<Earning[]>({
    queryKey: ['/api/employee/earnings'],
    refetchInterval: 30000,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0, 
      x: 20,
      transition: { duration: 0.2 }
    }
  };

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            <span>Recent Earnings</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: i * 0.1 }}
                className="flex items-center justify-between p-3 rounded-lg bg-secondary/10"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gray-200 rounded-full animate-pulse"></div>
                  <div className="space-y-1">
                    <div className="h-4 bg-gray-200 rounded w-20 animate-pulse"></div>
                    <div className="h-3 bg-gray-200 rounded w-16 animate-pulse"></div>
                  </div>
                </div>
                <div className="h-5 bg-gray-200 rounded w-12 animate-pulse"></div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <CardTitle className="flex items-center space-x-2">
            <motion.div
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
            >
              <DollarSign className="w-5 h-5 text-green-600" />
            </motion.div>
            <span>Recent Earnings</span>
          </CardTitle>
        </motion.div>
      </CardHeader>
      <CardContent>
        <AnimatePresence mode="popLayout">
          {!earnings || earnings.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center py-8 text-muted-foreground"
            >
              <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No earnings yet</p>
              <p className="text-sm">Start chatting to earn money!</p>
            </motion.div>
          ) : (
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="space-y-3"
            >
              {earnings.slice(0, 10).map((earning, index) => (
                <motion.div
                  key={earning.id}
                  variants={itemVariants}
                  whileHover={{ 
                    scale: 1.02, 
                    backgroundColor: "rgba(59, 130, 246, 0.05)" 
                  }}
                  className="flex items-center justify-between p-3 rounded-lg bg-secondary/10 border border-white/10 cursor-pointer transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: index * 0.1 + 0.2, type: "spring" }}
                      className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center"
                    >
                      {earning.conversation?.customerRating ? (
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      ) : (
                        <MessageSquare className="w-4 h-4 text-blue-500" />
                      )}
                    </motion.div>
                    
                    <div>
                      <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: index * 0.1 + 0.3 }}
                        className="text-sm font-medium"
                      >
                        Chat #{earning.conversationId}
                      </motion.p>
                      <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: index * 0.1 + 0.4 }}
                        className="text-xs text-muted-foreground flex items-center space-x-1"
                      >
                        <Clock className="w-3 h-3" />
                        <span>{
                          earning.earnedAt && !isNaN(new Date(earning.earnedAt).getTime()) 
                            ? formatDistanceToNow(new Date(earning.earnedAt), { addSuffix: true }) 
                            : 'Recently'
                        }</span>
                      </motion.p>
                    </div>
                  </div>
                  
                  <motion.div
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 + 0.5 }}
                    className="text-right"
                  >
                    <motion.p
                      whileHover={{ scale: 1.1 }}
                      className="text-sm font-bold text-green-600"
                    >
                      +${typeof earning.amount === 'number' ? earning.amount.toFixed(2) : '0.00'}
                    </motion.p>
                    {earning.conversation?.customerRating && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 + 0.6 }}
                        className="flex text-yellow-400"
                      >
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-2.5 h-2.5 ${
                              star <= (earning.conversation?.customerRating || 0) 
                                ? 'fill-yellow-400' 
                                : 'fill-gray-300'
                            }`}
                          />
                        ))}
                      </motion.div>
                    )}
                  </motion.div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}