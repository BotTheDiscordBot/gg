import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, User, Clock } from "lucide-react";
import { format } from "date-fns";

export default function EarningsBreakdown() {
  const { data: earnings, isLoading } = useQuery({
    queryKey: ['/api/employee/earnings'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const renderStars = (rating?: number) => {
    if (!rating) return null;
    
    return (
      <div className="flex text-yellow-400 text-xs">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-3 h-3 ${
              star <= rating ? 'fill-yellow-400' : 'fill-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  const getEarningsColor = (amount: number) => {
    if (amount >= 1.0) return "text-green-600";
    if (amount >= 0.5) return "text-green-500";
    return "text-gray-600";
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Earnings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center justify-between py-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-20"></div>
                      <div className="h-3 bg-gray-200 rounded w-16"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-12"></div>
                    <div className="h-3 bg-gray-200 rounded w-16"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Earnings</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-0 divide-y divide-gray-100">
          {earnings?.length > 0 ? (
            earnings.map((earning: any) => (
              <div key={earning.id} className="py-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="text-primary text-xs" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {earning.conversation?.chatNumber || 'Base Pay'}
                      </p>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-500">
                          {format(new Date(earning.earnedAt), 'h:mm a')}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-semibold ${getEarningsColor(Number(earning.amount))}`}>
                      +${Number(earning.amount).toFixed(2)}
                    </p>
                    {earning.conversation?.customerRating ? (
                      renderStars(earning.conversation.customerRating)
                    ) : (
                      <Badge variant="outline" className="text-xs">
                        {earning.type === 'base_pay' ? 'Base' : 'Bonus'}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">
              <User className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No earnings yet</p>
              <p className="text-sm">Complete your first chat to start earning!</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
