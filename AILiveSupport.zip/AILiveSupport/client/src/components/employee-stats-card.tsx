import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BarChart3, Clock, DollarSign, MessageSquare, Star } from "lucide-react";

interface EmployeeStatsCardProps {
  employee: {
    id: number;
    email: string;
    firstName: string;
    lastName: string;
    isActive: boolean;
    createdAt: string;
  };
  onViewDetails: (employee: any) => void;
}

export default function EmployeeStatsCard({ employee, onViewDetails }: EmployeeStatsCardProps) {
  const { data: stats } = useQuery<{
    todayEarnings: number;
    todayConversations: number;
    averageRating: number;
    totalEarnings: number;
  }>({
    queryKey: [`/api/admin/employee-stats/${employee.id}`],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: workSession } = useQuery<{
    id?: number;
    employeeId?: number;
    clockedIn?: string;
    clockedOut?: string | null;
    isOnBreak?: boolean;
    breakStarted?: string | null;
  }>({
    queryKey: [`/api/admin/employee-session/${employee.id}`],
    refetchInterval: 10000, // Check work status every 10 seconds
  });

  const getWorkStatus = () => {
    if (!employee.isActive) return { text: "Offline", color: "text-gray-500" };
    if (workSession?.isOnBreak) return { text: "On Break", color: "text-yellow-500" };
    if (workSession?.clockedIn && !workSession?.clockedOut) return { text: "Working", color: "text-green-500" };
    return { text: "Available", color: "text-blue-500" };
  };

  const workStatus = getWorkStatus();

  return (
    <div className="p-4 rounded-lg bg-secondary/20 border border-white/10 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
            <span className="text-sm font-bold">
              {employee.firstName[0]}{employee.lastName[0]}
            </span>
          </div>
          <div>
            <div className="font-medium text-lg">
              {employee.firstName} {employee.lastName}
            </div>
            <div className="text-sm text-muted-foreground">
              {employee.email}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant={employee.isActive ? "default" : "secondary"} className="flex items-center space-x-1">
            <div className={`w-2 h-2 rounded-full ${employee.isActive ? 'bg-green-500' : 'bg-gray-500'}`} />
            <span>{employee.isActive ? "Online" : "Offline"}</span>
          </Badge>
        </div>
      </div>
      
      {/* Employee Quick Stats */}
      <div className="grid grid-cols-4 gap-4 pt-3 border-t border-white/10">
        <div className="text-center">
          <div className="text-xs text-muted-foreground flex items-center justify-center space-x-1">
            <DollarSign className="h-3 w-3" />
            <span>Today</span>
          </div>
          <div className="font-semibold text-green-400">
            ${(stats?.todayEarnings ?? 0).toFixed(2)}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground flex items-center justify-center space-x-1">
            <MessageSquare className="h-3 w-3" />
            <span>Chats</span>
          </div>
          <div className="font-semibold">
            {stats?.todayConversations ?? 0}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground flex items-center justify-center space-x-1">
            <Star className="h-3 w-3" />
            <span>Rating</span>
          </div>
          <div className="font-semibold">
            {stats?.averageRating ? `${stats.averageRating.toFixed(1)}★` : 'N/A'}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground flex items-center justify-center space-x-1">
            <Clock className="h-3 w-3" />
            <span>Status</span>
          </div>
          <div className={`font-semibold ${workStatus.color}`}>
            {workStatus.text}
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-between pt-2">
        <div className="text-sm text-muted-foreground">
          Total Earned: ${(stats?.totalEarnings ?? 0).toFixed(2)}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onViewDetails(employee)}
          className="glass-button"
        >
          <BarChart3 className="h-4 w-4 mr-1" />
          View Details
        </Button>
      </div>
    </div>
  );
}