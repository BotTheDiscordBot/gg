import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { User, Star, Clock, MessageSquare, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { motion, AnimatePresence } from "framer-motion";

interface ChatQueueProps {
  onPickupChat: (conversationId: number) => void;
  disabled?: boolean;
}

interface QueueConversation {
  id: number;
  employeeId: number | null;
  aiCustomerId: number;
  status: string;
  issuePreview: string | null;
  startedAt: string;
  aiCustomer: {
    id: number;
    name: string;
    email: string;
    location: string;
    customerType: string;
    personalityType: string;
    avgRating: string | null;
    serviceType: string;
    orderNumber: string;
    trackingStatus: string;
  };
}

export default function AnimatedChatQueue({ onPickupChat, disabled }: ChatQueueProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: queue, isLoading } = useQuery<QueueConversation[]>({
    queryKey: ['/api/employee/queue'],
    refetchInterval: 5000,
  });

  const pickupChatMutation = useMutation({
    mutationFn: (conversationId: number) => 
      apiRequest(`/api/employee/pickup-chat/${conversationId}`, 'POST'),
    onSuccess: (_, conversationId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/employee/queue'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee/active-chats'] });
      onPickupChat(conversationId);
      toast({
        title: "Chat Picked Up",
        description: "You're now chatting with the customer!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Pick Up Chat",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getWaitingTime = (startedAt: string) => {
    return formatDistanceToNow(new Date(startedAt), { addSuffix: false });
  };

  const getWaitingColor = (startedAt: string) => {
    const minutes = (Date.now() - new Date(startedAt).getTime()) / (1000 * 60);
    if (minutes > 10) return "text-red-600";
    if (minutes > 5) return "text-yellow-600";
    return "text-blue-600";
  };

  const getWaitingExplanation = (startedAt: string) => {
    const minutes = (Date.now() - new Date(startedAt).getTime()) / (1000 * 60);
    if (minutes > 10) return "High priority - customer has been waiting";
    if (minutes > 5) return "Previous agent couldn't take this chat";
    if (minutes > 2) return "Transferred from busy agent";
    return "Just connected";
  };

  const renderStars = (rating?: number) => {
    if (!rating) return <span className="text-xs text-gray-500">New Customer</span>;
    
    return (
      <div className="flex items-center space-x-1">
        <div className="flex text-yellow-400">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={`w-3 h-3 ${
                star <= rating ? 'fill-yellow-400' : 'fill-gray-300'
              }`}
            />
          ))}
        </div>
        <span className="text-xs text-gray-500">{rating ? Number(rating).toFixed(1) : '0.0'} Avg</span>
      </div>
    );
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      x: 0,
      scale: 1,
      transition: { 
        duration: 0.3,
        type: "spring",
        stiffness: 100
      }
    },
    exit: { 
      opacity: 0, 
      x: 20,
      scale: 0.95,
      transition: { duration: 0.2 }
    }
  };

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Available Chats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: i * 0.1 }}
                className="animate-pulse"
              >
                <div className="flex items-center space-x-4 p-4">
                  <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                  <div className="space-y-2 flex-1">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <CardTitle className="flex items-center space-x-2">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
            >
              <MessageSquare className="h-5 w-5 text-blue-600" />
            </motion.div>
            <span>Available Chats</span>
            {queue && queue.length > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200 }}
              >
                <Badge variant="secondary" className="ml-2">
                  {queue.length}
                </Badge>
              </motion.div>
            )}
          </CardTitle>
        </motion.div>
      </CardHeader>
      <CardContent>
        <AnimatePresence mode="popLayout">
          {!queue || queue.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center py-8 text-muted-foreground"
            >
              <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No customers waiting</p>
              <p className="text-sm">New chats will appear here</p>
            </motion.div>
          ) : (
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="space-y-0 divide-y divide-gray-100"
            >
              {queue.map((conversation, index) => (
                <motion.div
                  key={conversation.id}
                  variants={itemVariants}
                  whileHover={{ 
                    scale: 1.02, 
                    backgroundColor: "rgba(59, 130, 246, 0.05)",
                    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)"
                  }}
                  className={`p-4 transition-colors cursor-pointer ${
                    disabled ? 'opacity-50' : ''
                  }`}
                  onClick={() => {
                    if (!disabled) {
                      pickupChatMutation.mutate(conversation.id);
                    }
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 flex-1">
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: index * 0.1 + 0.2, type: "spring" }}
                      >
                        <Avatar>
                          <AvatarFallback>
                            <User className="w-4 h-4" />
                          </AvatarFallback>
                        </Avatar>
                      </motion.div>
                      
                      <div className="flex-1 min-w-0">
                        <motion.div
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 + 0.3 }}
                          className="flex items-center justify-between"
                        >
                          <div>
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {conversation.aiCustomer?.name && conversation.aiCustomer.name !== "No Name Provided" 
                                ? conversation.aiCustomer.name 
                                : `Customer #${conversation.id}`}
                            </p>
                            <p className="text-xs text-gray-500 truncate">
                              {conversation.aiCustomer?.location || "Location not provided"}
                            </p>
                          </div>
                        </motion.div>
                        
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: index * 0.1 + 0.4 }}
                          className="mt-1 flex items-center justify-between"
                        >
                          <div className="flex items-center space-x-2">
                            <Clock className="w-3 h-3 text-gray-400" />
                            <span className={`text-sm font-medium ${getWaitingColor(conversation.startedAt)}`}>
                              {getWaitingTime(conversation.startedAt)}
                            </span>
                          </div>
                          {conversation.aiCustomer?.name && conversation.aiCustomer.name !== "No Name Provided" && conversation.aiCustomer.avgRating && renderStars(parseFloat(conversation.aiCustomer.avgRating))}
                        </motion.div>
                        
                        {conversation.issuePreview && (
                          <motion.div
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 + 0.5 }}
                            className="mt-2 p-2 bg-orange-50 border border-orange-200 rounded-md"
                          >
                            <div className="flex items-center space-x-1 mb-1">
                              <AlertCircle className="w-3 h-3 text-orange-600" />
                              <span className="text-xs font-medium text-orange-800">Issue</span>
                            </div>
                            <p className="text-xs text-orange-700 leading-relaxed">
                              {conversation.issuePreview}
                            </p>
                          </motion.div>
                        )}
                        
                        <motion.p
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: index * 0.1 + 0.6 }}
                          className="text-xs text-gray-400 mt-1"
                        >
                          {getWaitingExplanation(conversation.startedAt)}
                        </motion.p>
                      </div>
                    </div>
                    
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 + 0.6 }}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Button
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!disabled) {
                            pickupChatMutation.mutate(conversation.id);
                          }
                        }}
                        disabled={disabled || pickupChatMutation.isPending}
                        className="glass-button"
                      >
                        {pickupChatMutation.isPending ? 'Connecting...' : 'Pick Up'}
                      </Button>
                    </motion.div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}