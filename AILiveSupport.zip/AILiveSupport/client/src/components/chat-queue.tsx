import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Clock, Star, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";

interface ChatQueueProps {
  onPickupChat: (conversationId: number) => void;
  disabled?: boolean;
}

export default function ChatQueue({ onPickupChat, disabled }: ChatQueueProps) {
  const { toast } = useToast();

  // Fetch waiting conversations
  const { data: queue, isLoading } = useQuery<Array<{
    id: number;
    employeeId: number | null;
    aiCustomerId: number;
    chatNumber: string;
    status: string;
    startedAt: string;
    aiCustomer: {
      id: number;
      name: string;
      email: string;
      location: string;
      customerType: string;
      personalityType: string;
      avgRating: string | null;
      serviceType: string;
      orderNumber: string;
      trackingStatus: string;
    };
  }>>({
    queryKey: ['/api/employee/queue'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const pickupChatMutation = useMutation({
    mutationFn: (conversationId: number) => 
      apiRequest(`/api/employee/pickup-chat/${conversationId}`, 'POST'),
    onSuccess: (_, conversationId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/employee/queue'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee/active-chats'] });
      onPickupChat(conversationId);
      toast({
        title: "Chat Picked Up",
        description: "You're now chatting with the customer!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Pick Up Chat",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getWaitingTime = (startedAt: string) => {
    return formatDistanceToNow(new Date(startedAt), { addSuffix: false });
  };

  const getWaitingColor = (startedAt: string) => {
    const minutes = (Date.now() - new Date(startedAt).getTime()) / (1000 * 60);
    if (minutes > 10) return "text-red-600";
    if (minutes > 5) return "text-yellow-600";
    return "text-blue-600";
  };

  const renderStars = (rating?: number) => {
    if (!rating) return <span className="text-xs text-gray-500">New Customer</span>;
    
    return (
      <div className="flex items-center space-x-1">
        <div className="flex text-yellow-400">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={`w-3 h-3 ${
                star <= rating ? 'fill-yellow-400' : 'fill-gray-300'
              }`}
            />
          ))}
        </div>
        <span className="text-xs text-gray-500">{rating ? Number(rating).toFixed(1) : '0.0'} Avg</span>
      </div>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Available Chats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center space-x-4 p-4">
                  <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                  <div className="space-y-2 flex-1">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Available Chats</CardTitle>
          <Badge variant="secondary">
            {queue?.length || 0} waiting
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {disabled && (
          <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-700">
              {disabled ? "Clock in to start taking chats" : "Take a break to pause new chats"}
            </p>
          </div>
        )}
        
        <div className="space-y-0 divide-y divide-gray-100">
          {queue && queue.length > 0 ? (
            queue.map((conversation) => (
              <div
                key={conversation.id}
                className={`p-4 hover:bg-gray-50 transition-colors ${
                  disabled ? 'opacity-50' : 'cursor-pointer'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 flex-1">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback>
                        <User className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">
                        {conversation.aiCustomer?.name || "No Name Provided"}
                      </p>
                      <div className="flex items-center space-x-2 mb-1">
                        {conversation.aiCustomer?.name && conversation.aiCustomer.name !== "No Name Provided" && (
                          <Badge variant="outline" className="text-xs">
                            {conversation.aiCustomer?.customerType}
                          </Badge>
                        )}
                        <span className="text-xs text-gray-500">
                          {conversation.aiCustomer?.location}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 truncate max-w-xs">
                        "Waiting for support..."
                      </p>
                    </div>
                  </div>
                  <div className="text-right space-y-1">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3 text-gray-400" />
                      <span className={`text-sm font-medium ${getWaitingColor(conversation.startedAt)}`}>
                        {getWaitingTime(conversation.startedAt)}
                      </span>
                    </div>
                    {conversation.aiCustomer?.name && conversation.aiCustomer.name !== "No Name Provided" && conversation.aiCustomer.avgRating && renderStars(parseFloat(conversation.aiCustomer.avgRating))}
                    <Button
                      size="sm"
                      onClick={() => pickupChatMutation.mutate(conversation.id)}
                      disabled={disabled || pickupChatMutation.isPending}
                      className="w-full mt-2"
                    >
                      {pickupChatMutation.isPending ? "Picking up..." : "Pick Up"}
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">
              <User className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No customers waiting</p>
              <p className="text-sm">New chats will appear here automatically</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
