import { AnimatedStatCard } from "@/components/animated-stat-card";
import { DollarSign, MessageSquare, Star, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

interface MetricsGridProps {
  stats?: {
    todayEarnings: number;
    todayConversations: number;
    averageRating: number;
    totalEarnings: number;
  };
  isLoading: boolean;
}

export default function MetricsGrid({ stats, isLoading }: MetricsGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: i * 0.1 }}
            className="glass-card p-6 space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="h-4 w-20 bg-muted animate-pulse rounded"></div>
              <div className="h-4 w-4 bg-muted animate-pulse rounded"></div>
            </div>
            <div className="h-8 w-16 bg-muted animate-pulse rounded"></div>
            <div className="h-3 w-24 bg-muted animate-pulse rounded"></div>
          </motion.div>
        ))}
      </div>
    );
  }

  return (
    <motion.div 
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <AnimatedStatCard
        title="Today's Earnings"
        value={stats?.todayEarnings || 0}
        subtitle="Ready to earn more!"
        icon={DollarSign}
        prefix="$"
        decimals={2}
        delay={0}
        color="text-green-600"
      />

      <AnimatedStatCard
        title="Conversations"
        value={stats?.todayConversations || 0}
        subtitle="Today's total"
        icon={MessageSquare}
        delay={0.1}
        color="text-blue-600"
      />

      <AnimatedStatCard
        title="Average Rating"
        value={stats?.averageRating || 0}
        subtitle="Customer satisfaction"
        icon={Star}
        suffix="/5.0"
        decimals={1}
        delay={0.2}
        color="text-yellow-600"
      />

      <AnimatedStatCard
        title="Total Earnings"
        value={stats?.totalEarnings || 0}
        subtitle="All time"
        icon={TrendingUp}
        prefix="$"
        decimals={2}
        delay={0.3}
        color="text-purple-600"
      />
    </motion.div>
  );
}
