import { useCountUp } from "@/hooks/useCountUp";
import { AnimatedProgressRing } from "@/components/animated-progress-ring";
import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";

interface AnimatedStatCardProps {
  title: string;
  value: number;
  subtitle?: string;
  icon: LucideIcon;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  delay?: number;
  color?: string;
  maxValue?: number;
}

export function AnimatedStatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  prefix = "",
  suffix = "",
  decimals = 0,
  delay = 0,
  color = "text-primary",
  maxValue
}: AnimatedStatCardProps) {
  const { value: animatedValue, isAnimating } = useCountUp({
    end: value,
    duration: 2000,
    decimals,
    prefix,
    suffix
  });

  const progressPercentage = maxValue ? Math.min((value / maxValue) * 100, 100) : 75;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ scale: 1.02, y: -2 }}
      className="h-full"
    >
      <div className="glass-card h-full overflow-hidden relative group p-6 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg">
        {/* Floating background orbs */}
        <motion.div
          className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-blue-400/20 to-purple-400/20 rounded-full blur-sm"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{ 
            duration: 3, 
            repeat: Infinity,
            delay: delay 
          }}
        />
        
        <motion.div
          className="absolute -bottom-1 -left-1 w-6 h-6 bg-gradient-to-r from-purple-400/20 to-pink-400/20 rounded-full blur-sm"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.4, 0.2, 0.4]
          }}
          transition={{ 
            duration: 4, 
            repeat: Infinity,
            delay: delay + 0.5 
          }}
        />
        
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <motion.h3 
              className="text-sm font-medium text-muted-foreground mb-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: delay + 0.2 }}
            >
              {title}
            </motion.h3>
            
            <motion.div 
              className="text-2xl font-bold text-foreground"
              animate={{ 
                scale: isAnimating ? [1, 1.05, 1] : 1,
              }}
              transition={{ duration: 0.3 }}
            >
              {animatedValue}
            </motion.div>
          </div>
          
          <div className="flex flex-col items-center space-y-2">
            <motion.div
              whileHover={{ rotate: 10, scale: 1.1 }}
              transition={{ type: "spring", stiffness: 300 }}
              className="p-2 rounded-lg bg-white/10"
            >
              <Icon className={`h-5 w-5 ${color}`} />
            </motion.div>
            
            <AnimatedProgressRing
              progress={progressPercentage}
              size={32}
              strokeWidth={2}
              color={color.includes('green') ? '#16a34a' : 
                     color.includes('blue') ? '#2563eb' :
                     color.includes('yellow') ? '#ca8a04' : '#9333ea'}
              delay={delay + 0.8}
            />
          </div>
        </div>
        
        {subtitle && (
          <motion.p 
            className="text-xs text-muted-foreground"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: delay + 0.5 }}
          >
            {subtitle}
          </motion.p>
        )}
        
        {/* Animated bottom border */}
        <motion.div
          className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full"
          initial={{ width: "0%" }}
          animate={{ width: "100%" }}
          transition={{ duration: 1.5, delay: delay + 0.3 }}
        />
        
        {/* Pulse effect on hover */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 rounded-lg"
          initial={false}
          transition={{ duration: 0.3 }}
        />
      </div>
    </motion.div>
  );
}