import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Star } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function RecentReviews() {
  const { data: conversations, isLoading } = useQuery({
    queryKey: ['/api/employee/recent-conversations'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const renderStars = (rating: number) => {
    return (
      <div className="flex text-yellow-400 text-sm">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= rating ? 'fill-yellow-400' : 'fill-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Reviews</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse py-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="h-4 bg-gray-200 rounded w-20"></div>
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-full mb-1"></div>
                <div className="h-3 bg-gray-200 rounded w-24"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Filter only conversations with reviews
  const reviewedConversations = conversations?.filter((conv: any) => 
    conv.customerReview && conv.customerRating
  ) || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Reviews</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-0 divide-y divide-gray-100">
          {reviewedConversations.length > 0 ? (
            reviewedConversations.slice(0, 5).map((conversation: any) => (
              <div key={conversation.id} className="py-4">
                <div className="flex items-center justify-between mb-2">
                  {renderStars(conversation.customerRating)}
                  <span className="text-xs text-gray-500">
                    {formatDistanceToNow(new Date(conversation.completedAt), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-sm text-gray-700 mb-2">
                  "{conversation.customerReview}"
                </p>
                <div className="flex items-center justify-between">
                  <p className="text-xs text-gray-500">
                    {conversation.aiCustomer?.name}
                  </p>
                  <p className="text-xs text-green-600 font-medium">
                    +${Number(conversation.earnings).toFixed(2)}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Star className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No reviews yet</p>
              <p className="text-sm">Customer reviews will appear here after completed chats</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
