import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  DollarSign, 
  MessageSquare, 
  Star, 
  Clock, 
  TrendingUp, 
  Activity,
  Calendar,
  User,
  Mail,
  Timer
} from "lucide-react";

interface EmployeeDetailModalProps {
  employee: any;
  isOpen: boolean;
  onClose: () => void;
}

export default function EmployeeDetailModal({ employee, isOpen, onClose }: EmployeeDetailModalProps) {
  const { data: stats } = useQuery<{
    todayEarnings: number;
    todayConversations: number;
    averageRating: number;
    totalEarnings: number;
  }>({
    queryKey: [`/api/admin/employee-stats/${employee?.id}`],
    enabled: !!employee?.id,
    refetchInterval: 15000,
  });

  const { data: workSession } = useQuery<{
    id?: number;
    employeeId?: number;
    clockedIn?: string;
    clockedOut?: string | null;
    isOnBreak?: boolean;
    breakStarted?: string | null;
  }>({
    queryKey: [`/api/admin/employee-session/${employee?.id}`],
    enabled: !!employee?.id,
    refetchInterval: 5000,
  });

  const { data: recentConversations } = useQuery<Array<{
    id: number;
    customerRating?: number;
    completedAt?: string;
    aiCustomer: {
      name: string;
      serviceType: string;
    };
  }>>({
    queryKey: [`/api/admin/employee-conversations/${employee?.id}`],
    enabled: !!employee?.id,
  });

  if (!employee) return null;

  const getWorkStatus = () => {
    if (!employee.isActive) return { text: "Offline", color: "bg-gray-500", textColor: "text-gray-100" };
    if (workSession?.isOnBreak) return { text: "On Break", color: "bg-yellow-500", textColor: "text-yellow-100" };
    if (workSession?.clockedIn && !workSession?.clockedOut) return { text: "Working", color: "bg-green-500", textColor: "text-green-100" };
    return { text: "Available", color: "bg-blue-500", textColor: "text-blue-100" };
  };

  const workStatus = getWorkStatus();
  const workDuration = workSession?.clockedIn && !workSession?.clockedOut 
    ? Math.floor((new Date().getTime() - new Date(workSession.clockedIn).getTime()) / (1000 * 60))
    : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl glass-card border-white/20">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-lg font-bold">
                {employee.firstName[0]}{employee.lastName[0]}
              </span>
            </div>
            <div>
              <div className="text-xl font-bold">
                {employee.firstName} {employee.lastName}
              </div>
              <div className="text-sm text-muted-foreground">
                Employee Performance Dashboard
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status and Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="glass-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span>Employee Info</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{employee.email}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Joined {new Date(employee.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Activity className="h-4 w-4 text-muted-foreground" />
                  <Badge className={`${workStatus.color} ${workStatus.textColor}`}>
                    {workStatus.text}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <Timer className="h-4 w-4" />
                  <span>Work Session</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {workSession?.clockedIn ? (
                  <>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Clocked In:</span>
                      <span className="text-sm">
                        {new Date(workSession.clockedIn).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Duration:</span>
                      <span className="text-sm font-semibold">
                        {Math.floor(workDuration / 60)}h {workDuration % 60}m
                      </span>
                    </div>
                    {workSession.isOnBreak && workSession.breakStarted && (
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Break Since:</span>
                        <span className="text-sm">
                          {new Date(workSession.breakStarted).toLocaleTimeString()}
                        </span>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-sm text-muted-foreground">Not currently working</div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Performance Metrics */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5" />
                <span>Performance Metrics</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-primary/10 rounded-lg">
                  <DollarSign className="h-6 w-6 mx-auto mb-2 text-green-400" />
                  <div className="text-2xl font-bold text-green-400">
                    ${(stats?.todayEarnings ?? 0).toFixed(2)}
                  </div>
                  <div className="text-xs text-muted-foreground">Today's Earnings</div>
                </div>
                <div className="text-center p-4 bg-primary/10 rounded-lg">
                  <MessageSquare className="h-6 w-6 mx-auto mb-2 text-blue-400" />
                  <div className="text-2xl font-bold">
                    {stats?.todayConversations ?? 0}
                  </div>
                  <div className="text-xs text-muted-foreground">Conversations Today</div>
                </div>
                <div className="text-center p-4 bg-primary/10 rounded-lg">
                  <Star className="h-6 w-6 mx-auto mb-2 text-yellow-400" />
                  <div className="text-2xl font-bold">
                    {stats?.averageRating ? `${stats.averageRating.toFixed(1)}★` : 'N/A'}
                  </div>
                  <div className="text-xs text-muted-foreground">Average Rating</div>
                </div>
                <div className="text-center p-4 bg-primary/10 rounded-lg">
                  <DollarSign className="h-6 w-6 mx-auto mb-2 text-purple-400" />
                  <div className="text-2xl font-bold">
                    ${(stats?.totalEarnings ?? 0).toFixed(2)}
                  </div>
                  <div className="text-xs text-muted-foreground">Total Earnings</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Conversations */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageSquare className="h-5 w-5" />
                <span>Recent Conversations</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {recentConversations && recentConversations.length > 0 ? (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {recentConversations.map((conv) => (
                    <div key={conv.id} className="flex items-center justify-between p-3 bg-secondary/20 rounded-lg">
                      <div>
                        <div className="font-medium">{conv.aiCustomer.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {conv.aiCustomer.serviceType}
                        </div>
                      </div>
                      <div className="text-right">
                        {conv.customerRating ? (
                          <div className="text-yellow-400">
                            {conv.customerRating}★
                          </div>
                        ) : (
                          <div className="text-muted-foreground">No rating</div>
                        )}
                        {conv.completedAt && (
                          <div className="text-xs text-muted-foreground">
                            {new Date(conv.completedAt).toLocaleTimeString()}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  No recent conversations
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={onClose} variant="outline" className="glass-button">
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}