import { useQuery } from "@tanstack/react-query";

interface EmployeeUser {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  profileImageUrl?: string;
}

interface AdminUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  profileImageUrl?: string;
}

export function useAuth() {
  const employeeToken = typeof window !== 'undefined' ? localStorage.getItem('employee_token') : null;
  const adminToken = typeof window !== 'undefined' ? localStorage.getItem('admin_token') : null;

  // Get employee data if employee token exists
  const { data: employeeUser, isLoading: employeeLoading } = useQuery<EmployeeUser>({
    queryKey: ["/api/employee/me"],
    retry: false,
    enabled: !!employeeToken,
  });

  // Get admin data if admin token exists
  const { data: adminUser, isLoading: adminLoading } = useQuery<AdminUser>({
    queryKey: ["/api/admin/me"],
    retry: false,
    enabled: !!adminToken,
  });

  const isEmployee = !!employeeToken && !!employeeUser;
  const isAdmin = !!adminToken && !!adminUser;
  const isAuthenticated = isEmployee || isAdmin;
  const isLoading = employeeToken ? employeeLoading : adminLoading;

  const user = employeeUser || adminUser;

  return {
    user,
    isLoading,
    isAuthenticated,
    isEmployee,
    isAdmin,
  };
}