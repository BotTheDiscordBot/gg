import { useState, useEffect } from 'react';

interface UseCountUpOptions {
  end: number;
  duration?: number;
  start?: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
}

export function useCountUp({ 
  end, 
  duration = 2000, 
  start = 0, 
  decimals = 0,
  prefix = '',
  suffix = ''
}: UseCountUpOptions) {
  const [current, setCurrent] = useState(start);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (end === current) return;

    setIsAnimating(true);
    const range = end - start;
    const increment = range / (duration / 16); // 60fps
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Ease out animation
      const easeOut = 1 - Math.pow(1 - progress, 3);
      const value = start + range * easeOut;
      
      setCurrent(value);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setCurrent(end);
        setIsAnimating(false);
      }
    };

    requestAnimationFrame(animate);
  }, [end, start, duration]);

  const formatValue = (value: number) => {
    const formatted = value.toFixed(decimals);
    return `${prefix}${formatted}${suffix}`;
  };

  return {
    value: formatValue(current),
    isAnimating
  };
}