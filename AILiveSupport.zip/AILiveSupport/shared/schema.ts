import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for admin auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Admin users table (for Replit auth)
export const adminUsers = pgTable("admin_users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Employee accounts
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  email: varchar("email").notNull().unique(),
  password: varchar("password").notNull(),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  profileImageUrl: varchar("profile_image_url"),
  isActive: boolean("is_active").default(true),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }).default("15.00"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Work sessions for time tracking
export const workSessions = pgTable("work_sessions", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  clockInTime: timestamp("clock_in_time").notNull(),
  clockOutTime: timestamp("clock_out_time"),
  totalMinutes: integer("total_minutes"),
  isOnBreak: boolean("is_on_break").default(false),
  breakStartTime: timestamp("break_start_time"),
  totalBreakMinutes: integer("total_break_minutes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI customer personalities
export const aiCustomers = pgTable("ai_customers", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  email: varchar("email").notNull(),
  location: varchar("location"),
  customerType: varchar("customer_type").notNull(), // Premium, VIP, New, etc.
  personalityType: varchar("personality_type").notNull(), // impatient, confused, angry, polite, etc.
  profileImageUrl: varchar("profile_image_url"),
  avgRating: decimal("avg_rating", { precision: 2, scale: 1 }),
  serviceType: varchar("service_type"), // game_script, 3d_model, ui_design, animation, sound_effect, music_track, bot_setup
  orderNumber: varchar("order_number"), // fake tracking number like "HYB-2024-1847"
  trackingStatus: varchar("tracking_status"), // being_scripted, being_modeled, rendering, sound_mixing, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat conversations
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id),
  aiCustomerId: integer("ai_customer_id").notNull().references(() => aiCustomers.id),
  chatNumber: varchar("chat_number").notNull().unique(),
  status: varchar("status").notNull().default("waiting"), // waiting, active, completed, abandoned
  issuePreview: text("issue_preview"), // Brief description of the customer's problem
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  totalMinutes: integer("total_minutes"),
  customerRating: integer("customer_rating"), // 1-5 stars
  customerReview: text("customer_review"),
  earnings: decimal("earnings", { precision: 10, scale: 2 }),
  wasAbandoned: boolean("was_abandoned").default(false),
});

// Chat messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  senderType: varchar("sender_type").notNull(), // employee, customer
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Employee earnings tracking
export const earnings = pgTable("earnings", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  conversationId: integer("conversation_id").references(() => conversations.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  type: varchar("type").notNull(), // base_pay, star_bonus, hourly
  description: varchar("description"),
  earnedAt: timestamp("earned_at").defaultNow(),
});

// Activity logging for comprehensive employee tracking
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  activityType: varchar("activity_type", { length: 50 }).notNull(), // CLOCK_IN, CLOCK_OUT, BREAK_START, BREAK_END, CHAT_PICKED_UP, CHAT_COMPLETED
  description: text("description").notNull(),
  metadata: jsonb("metadata"), // Additional data about the activity
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Relations
export const employeesRelations = relations(employees, ({ many }) => ({
  workSessions: many(workSessions),
  conversations: many(conversations),
  earnings: many(earnings),
  activityLogs: many(activityLogs),
}));

export const workSessionsRelations = relations(workSessions, ({ one }) => ({
  employee: one(employees, {
    fields: [workSessions.employeeId],
    references: [employees.id],
  }),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  employee: one(employees, {
    fields: [conversations.employeeId],
    references: [employees.id],
  }),
  aiCustomer: one(aiCustomers, {
    fields: [conversations.aiCustomerId],
    references: [aiCustomers.id],
  }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
}));

export const earningsRelations = relations(earnings, ({ one }) => ({
  employee: one(employees, {
    fields: [earnings.employeeId],
    references: [employees.id],
  }),
  conversation: one(conversations, {
    fields: [earnings.conversationId],
    references: [conversations.id],
  }),
}));

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  employee: one(employees, {
    fields: [activityLogs.employeeId],
    references: [employees.id],
  }),
}));

// Insert schemas
export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertWorkSessionSchema = createInsertSchema(workSessions).omit({
  id: true,
  createdAt: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  startedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  timestamp: true,
});

export const insertEarningsSchema = createInsertSchema(earnings).omit({
  id: true,
  earnedAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  timestamp: true,
});

// Types
export type AdminUser = typeof adminUsers.$inferSelect;
export type UpsertAdminUser = typeof adminUsers.$inferInsert;
export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type WorkSession = typeof workSessions.$inferSelect;
export type InsertWorkSession = z.infer<typeof insertWorkSessionSchema>;
export type AiCustomer = typeof aiCustomers.$inferSelect;
export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Earnings = typeof earnings.$inferSelect;
export type InsertEarnings = z.infer<typeof insertEarningsSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
