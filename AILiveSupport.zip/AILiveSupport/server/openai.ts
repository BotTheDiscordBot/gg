import OpenAI from "openai";
import type { Conversation, AiCustomer, Message } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

const customerPersonalities = {
  impatient: {
    traits: "Very impatient, uses short messages, types quickly with occasional typos, gets frustrated with delays",
    responsePatterns: ["quick responses", "short sentences", "may use caps when angry", "frequent typos"]
  },
  confused: {
    traits: "Genuinely confused about technology, asks lots of questions, needs things explained simply",
    responsePatterns: ["asks clarifying questions", "uses simple language", "expresses confusion clearly"]
  },
  angry: {
    traits: "Already frustrated with the company/product, demanding immediate resolution, may be rude",
    responsePatterns: ["demanding tone", "mentions previous bad experiences", "wants escalation"]
  },
  polite: {
    traits: "Very courteous and understanding, patient with the process, appreciative of help",
    responsePatterns: ["uses please and thank you", "apologetic for taking time", "positive language"]
  },
  tech_savvy: {
    traits: "Knows technical terms, provides detailed information, expects efficient solutions",
    responsePatterns: ["technical terminology", "detailed descriptions", "efficient communication"]
  },
  elderly: {
    traits: "Less familiar with technology, speaks more formally, may need extra patience and explanation",
    responsePatterns: ["formal language", "asks for step-by-step help", "mentions age or technology difficulty"]
  },
  millennial: {
    traits: "Casual communication style, uses internet slang occasionally, expects quick responses",
    responsePatterns: ["casual language", "occasional slang", "abbreviated words like 'u' instead of 'you'"]
  },
  suspicious: {
    traits: "Distrusts company motives, asks probing questions, skeptical of solutions offered",
    responsePatterns: ["questioning motives", "asking for proof", "expressing doubt"]
  }
};

export async function generateAIResponse(
  conversation: Conversation, 
  messages: Message[],
  aiCustomer?: any
): Promise<{ type: 'message' | 'end_chat'; content?: string }> {
  try {
    // Use the actual AI customer personality if available
    const personalityType = aiCustomer?.personalityType || 'polite';
    const personality = customerPersonalities[personalityType as keyof typeof customerPersonalities] || customerPersonalities.polite;

    // Determine if customer should leave based on conversation progress
    const customerMessages = messages.filter(m => m.senderType === 'customer');
    const employeeMessages = messages.filter(m => m.senderType === 'employee');
    
    // 20% chance to abruptly leave conversation after 2+ exchanges
    const shouldAbruptlyLeave = customerMessages.length >= 2 && Math.random() < 0.20;
    
    // Higher chance to leave if issue seems resolved (based on keywords)
    const lastEmployeeMessage = employeeMessages[employeeMessages.length - 1]?.content || '';
    const resolutionKeywords = ['fixed', 'solved', 'working', 'resolved', 'should work', 'try that', 'done', 'complete', 'that works', 'working now', 'all set', 'good to go'];
    const seemsResolved = resolutionKeywords.some(keyword => lastEmployeeMessage.toLowerCase().includes(keyword));
    const shouldLeaveAfterResolution = seemsResolved; // 100% chance to leave when resolved

    if (shouldAbruptlyLeave || shouldLeaveAfterResolution) {
      return { type: 'end_chat' };
    }

    // Build conversation context
    const conversationHistory = messages.map(msg => 
      `${msg.senderType === 'employee' ? 'Agent' : 'Customer'}: ${msg.content}`
    ).join('\n');

    const customerName = aiCustomer?.name || "Anonymous";
    const serviceType = aiCustomer?.serviceType || "game development";
    const orderNumber = aiCustomer?.orderNumber || `HYB-${Math.floor(Math.random() * 10000)}`;
    
    const isFirstCustomerMessage = messages.filter(m => m.senderType === 'customer').length === 0;
    
    // Generate unique problems based on customer ID and service type
    const problemsByService = {
      'game_development': [
        "My Unity game script has a bug where players fall through the floor randomly",
        "The collision detection isn't working properly in my platformer game",
        "My RPG inventory system is duplicating items when players save/load",
        "The enemy AI pathfinding gets stuck on corners and walls",
        "My multiplayer game has sync issues where players teleport around",
        "The game crashes when trying to load the second level",
        "My character controller feels too floaty and unresponsive"
      ],
      'bot_development': [
        "My Discord bot stops responding after a few hours of running",
        "The bot's moderation commands aren't working in certain channels",
        "Users can't use bot commands even though they have the right permissions",
        "The economy system is giving out way too much currency",
        "My music bot has terrible audio quality and keeps cutting out",
        "The auto-role assignment feature broke after the last Discord update",
        "Bot commands have a huge delay before responding"
      ],
      '3d_modeling': [
        "The 3D model has weird shading artifacts that I can't fix",
        "The texture mapping is completely wrong on the character's face",
        "My model's animations are jittery and don't loop smoothly",
        "The exported model is missing several parts when I import it",
        "The file size is way too large for my game engine",
        "The model's proportions look off compared to the reference art",
        "Some vertices are floating in mid-air and breaking the mesh"
      ],
      'ui_design': [
        "The interface doesn't scale properly on different screen sizes",
        "The button colors don't match the design mockups we agreed on",
        "The navigation menu overlaps with content on mobile devices",
        "Text is barely readable against the background images",
        "The loading animations are way too slow and annoying",
        "Form validation messages aren't showing up when users make errors",
        "The dark mode toggle isn't working consistently"
      ],
      'animation': [
        "The character walk cycle looks robotic and unnatural",
        "There's a weird pop between idle and running animations",
        "The facial expressions don't sync with the voice acting",
        "Some frames have artifacts and visual glitches",
        "The animation timing is off and feels too fast",
        "Background elements are moving when they should be static",
        "The exported video has compression issues"
      ],
      'sound_design': [
        "The audio levels are completely inconsistent between different sounds",
        "There's a weird echo/reverb that makes dialogue hard to understand",
        "Sound effects cut off abruptly instead of fading naturally",
        "The background music is too loud and drowns out important sounds",
        "Audio files won't import properly into my game engine",
        "There's crackling and distortion in the high frequency ranges",
        "Some sounds trigger at the wrong times during gameplay"
      ],
      'web_development': [
        "The website loads extremely slowly on mobile connections",
        "Forms aren't submitting data correctly to the database",
        "The responsive design breaks on certain tablet sizes",
        "JavaScript errors are preventing users from checking out",
        "The search functionality returns completely wrong results",
        "Images aren't optimized and are taking forever to load",
        "The contact form sends emails but they go to spam"
      ]
    };

    let prompt = '';
    if (isFirstCustomerMessage) {
      // Use customer ID to ensure consistent problem selection
      const validServiceTypes = ['game_development', 'bot_development', '3d_modeling', 'ui_design', 'animation', 'sound_design', 'web_development'];
      const normalizedServiceType = validServiceTypes.includes(serviceType) ? serviceType : 'game_development';
      const serviceProblems = problemsByService[normalizedServiceType as keyof typeof problemsByService];
      const problemIndex = (aiCustomer?.id || 1) % serviceProblems.length;
      const specificProblem = serviceProblems[problemIndex];
      
      prompt = `You are ${customerName}, a real customer contacting hostyourbot.com support. Your issue: ${specificProblem}

Your personality: ${personality.traits}
Communication style: ${personality.responsePatterns.join(', ')}

Start your conversation with: "This conversation may be archived and saved for security purposes."

Then explain your specific problem naturally. Reference your order #${orderNumber} for ${serviceType} work.

Guidelines:
- Act like a real person with genuine technical concerns
- Use natural language with occasional typos and contractions
- Show frustration, confusion, or urgency based on your personality
- Keep initial message brief (2-3 sentences after security notice)
- Don't reveal this is AI simulation
- Make it feel like a real programming/gaming support issue

Generate your opening message. Include the security notice first, then your specific technical problem.`;
    } else {
      // Extract the original problem from the first customer message to maintain consistency
      const firstCustomerMessage = messages.find(m => m.senderType === 'customer');
      const originalContext = firstCustomerMessage ? firstCustomerMessage.content : '';
      
      prompt = `You are ${customerName}, a real customer in ongoing support chat about your ${serviceType} order (#${orderNumber}).

Your personality: ${personality.traits}
Communication style: ${personality.responsePatterns.join(', ')}

Your original issue was: ${originalContext}

Current conversation:
${conversationHistory}

Guidelines:
- Stay consistent with your ORIGINAL ISSUE mentioned in your first message
- Your name is ${customerName} and your email is ${aiCustomer?.email || customerName.toLowerCase().replace(' ', '.')}@example.com
- If asked for personal information, provide realistic details that match your customer profile
- Act like a real person with genuine concerns about the same problem
- Use natural language with occasional typos, contractions, and informal speech
- Show appropriate emotions based on your personality
- Keep responses conversational and human-like (1-2 sentences typically)
- Don't mention being an AI or that this is a simulation
- Don't change your story or introduce new problems
- Respond thoughtfully to what the agent said, staying on topic

Generate your next message as ${customerName}. Respond ONLY with your message text.`;
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 200,
      temperature: 0.8,
    });

    const content = response.choices[0].message.content?.trim();
    
    return {
      type: 'message',
      content: content || "thanks for your help"
    };

  } catch (error) {
    console.error('Error generating AI response:', error);
    // Fallback response
    return {
      type: 'message',
      content: "ok thanks"
    };
  }
}

export async function generateCustomerRating(
  conversation: Conversation,
  messages: Message[]
): Promise<{ rating: number; review: string; wasAbandoned: boolean }> {
  try {
    // 20% chance customer leaves without rating
    if (Math.random() < 0.2) {
      return {
        rating: 0,
        review: "",
        wasAbandoned: true
      };
    }

    const conversationHistory = messages.map(msg => 
      `${msg.senderType === 'employee' ? 'Agent' : 'Customer'}: ${msg.content}`
    ).join('\n');

    const prompt = `Based on this customer service conversation, generate a realistic and harsh customer rating. Most customers are critical and hard to please. Respond in JSON format.

Conversation:
${conversationHistory}

Rating criteria (be very strict):
- 5 stars: EXTREMELY rare - perfect instant solution, agent went far above expectations
- 4 stars: Good but still find flaws, took too long or wasn't perfect
- 3 stars: Average, issue resolved but frustrated with process
- 2 stars: Poor service, agent seemed inexperienced or unhelpful
- 1 star: Terrible, issue not resolved, wasted time

Most ratings should be 1-3 stars. Customers blame agents for everything, get impatient quickly, and expect instant perfect solutions.

Generate a JSON response with:
{
  "rating": (1-5 stars, integer),
  "review": "harsh realistic review (1-15 words, frustrated customer language)"
}

Be harsh and critical. Customers rarely give 5 stars. Return only valid JSON.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 150,
      temperature: 0.7,
    });

    let content = response.choices[0].message.content || '{"rating": 3, "review": "ok thanks"}';
    // Remove markdown code blocks if present
    content = content.replace(/```json\s*|\s*```/g, '').trim();
    const result = JSON.parse(content);

    return {
      rating: Math.max(1, Math.min(5, result.rating)),
      review: result.review || "thanks",
      wasAbandoned: false
    };

  } catch (error) {
    console.error('Error generating customer rating:', error);
    // Fallback rating
    return {
      rating: Math.floor(Math.random() * 3) + 2, // 2-4 stars
      review: "thanks for help",
      wasAbandoned: false
    };
  }
}

export async function generateAICustomer(): Promise<{
  name: string;
  email: string;
  location: string;
  customerType: string;
  personalityType: string;
  profileImageUrl: string;
  avgRating?: number;
  serviceType: string;
  orderNumber: string;
  trackingStatus: string;
}> {
  try {
    const prompt = `Generate a realistic customer profile for a customer service platform. Please output a JSON object with these exact fields:

name: realistic full name
email: realistic email address
location: City, State abbreviation (US cities only)
customerType: one of Premium, VIP, New, or Regular  
personalityType: one of impatient, confused, angry, polite, tech_savvy, elderly, millennial, or suspicious
avgRating: number between 1.0-5.0 for how they typically rate service (or null for new customers)

Make it diverse and realistic. Output must be valid JSON format.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 200,
    });

    const customer = JSON.parse(response.choices[0].message.content || '{}');
    
    // Generate a random profile image URL from a service like UIFaces or Unsplash
    const profileImages = [
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face", 
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face",
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=face"
    ];

    const serviceTypes = ['game_script', '3d_model', 'ui_design', 'bot_setup', 'animation', 'sound_effect', 'music_track'];
    const trackingStatuses = ['being_processed', 'in_development', 'testing', 'quality_check', 'ready_for_delivery'];
    
    // Generate consistent email based on name
    const name = customer.name || "John Doe";
    const emailBase = name.toLowerCase().replace(/[^a-z\s]/g, '').replace(/\s+/g, '.');
    const consistentEmail = customer.email || `${emailBase}@example.com`;
    
    return {
      name: name,
      email: consistentEmail,
      location: customer.location || "New York, NY", 
      customerType: customer.customerType || "Regular",
      personalityType: customer.personalityType || "polite",
      profileImageUrl: profileImages[Math.floor(Math.random() * profileImages.length)],
      avgRating: customer.avgRating,
      serviceType: serviceTypes[Math.floor(Math.random() * serviceTypes.length)],
      orderNumber: `HYB-${Math.floor(Math.random() * 9000) + 1000}`,
      trackingStatus: trackingStatuses[Math.floor(Math.random() * trackingStatuses.length)]
    };

  } catch (error) {
    console.error('Error generating AI customer:', error);
    return {
      name: "Anonymous Customer",
      email: "customer@example.com",
      location: "Unknown",
      customerType: "Regular", 
      personalityType: "polite",
      profileImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
      serviceType: "game_script",
      orderNumber: `HYB-${Math.floor(Math.random() * 9000) + 1000}`,
      trackingStatus: "being_processed"
    };
  }
}
