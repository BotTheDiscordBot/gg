import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import jwt from "jsonwebtoken";
import { storage } from "./storage";
import { generateAIResponse, generateCustomerRating, generateAICustomer } from "./openai";
import { generateIssuePreview } from "./issueGenerator";
import { insertEmployeeSchema, insertMessageSchema } from "@shared/schema";
// Admin auth will be added later

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// JWT middleware for employee auth
const authenticateEmployee = async (req: any, res: any, next: any) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.replace('Bearer ', '');
    
    // For demo purposes, accept a mock token
    if (token === 'mock-employee-token-123') {
      const employee = await storage.getEmployeeByEmail('sarah.johnson@company.com');
      if (employee) {
        req.employee = employee;
        return next();
      }
    }
    
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const employee = await storage.getEmployee(decoded.employeeId);
    
    if (!employee) {
      return res.status(401).json({ message: "Invalid token" });
    }

    req.employee = employee;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({ message: "Invalid token" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const employeeConnections = new Map<number, WebSocket>();

  wss.on('connection', (ws, req) => {
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'authenticate') {
          const decoded = jwt.verify(message.token, JWT_SECRET) as any;
          const employee = await storage.getEmployee(decoded.employeeId);
          
          if (employee) {
            employeeConnections.set(employee.id, ws);
            ws.send(JSON.stringify({ type: 'authenticated', employeeId: employee.id }));
          }
        }
        
        if (message.type === 'send_message') {
          await handleChatMessage(message, ws);
        }
      } catch (error) {
        console.error('WebSocket error:', error);
      }
    });

    ws.on('close', () => {
      // Remove from connections
      employeeConnections.forEach((connection, employeeId) => {
        if (connection === ws) {
          employeeConnections.delete(employeeId);
        }
      });
    });
  });

  async function handleChatMessage(message: any, ws: WebSocket) {
    try {
      // Save employee message
      await storage.createMessage({
        conversationId: message.conversationId,
        senderType: 'employee',
        content: message.content,
      });

      // Get conversation details
      const conversation = await storage.getConversation(message.conversationId);
      if (!conversation) return;

      // Broadcast message to employee
      ws.send(JSON.stringify({
        type: 'message_sent',
        conversationId: message.conversationId,
        content: message.content,
        timestamp: new Date().toISOString(),
      }));

      // Simulate customer response delay
      setTimeout(async () => {
        const messages = await storage.getMessagesForConversation(message.conversationId);
        const aiResponse = await generateAIResponse(conversation, messages, conversation.aiCustomer);

        if (aiResponse.type === 'message') {
          // Save AI customer message
          await storage.createMessage({
            conversationId: message.conversationId,
            senderType: 'customer',
            content: aiResponse.content || 'Thanks for your help',
          });

          // Send to employee
          ws.send(JSON.stringify({
            type: 'customer_message',
            conversationId: message.conversationId,
            content: aiResponse.content,
            timestamp: new Date().toISOString(),
          }));
        } else if (aiResponse.type === 'end_chat') {
          // Customer is ending the chat
          const rating = await generateCustomerRating(conversation, messages);
          
          await storage.completeConversation(
            message.conversationId,
            rating.rating,
            rating.review,
            rating.wasAbandoned
          );

          ws.send(JSON.stringify({
            type: 'chat_ended',
            conversationId: message.conversationId,
            rating: rating.rating,
            review: rating.review,
            earnings: rating.wasAbandoned ? 0.25 : 0.25 + (rating.rating * 0.20),
          }));
        }
      }, Math.random() * 3000 + 1000); // 1-4 second delay
    } catch (error) {
      console.error('Error handling chat message:', error);
    }
  }

  // Admin authentication route
  app.post('/api/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      // Check for admin credentials
      if (email === 'Jahceere@hostyourbot.com' && password === 'state44here') {
        const admin = await storage.getAdminUser('admin_jahceere');
        if (!admin) {
          return res.status(401).json({ message: "Admin user not found" });
        }

        const token = jwt.sign({ adminId: admin.id }, JWT_SECRET, { expiresIn: '8h' });
        
        res.json({
          token,
          admin: {
            id: admin.id,
            email: admin.email,
            firstName: admin.firstName,
            lastName: admin.lastName,
            profileImageUrl: admin.profileImageUrl,
          }
        });
      } else {
        return res.status(401).json({ message: "Invalid admin credentials" });
      }
    } catch (error) {
      console.error('Admin login error:', error);
      res.status(500).json({ message: "Admin login failed" });
    }
  });

  // Admin logout route
  app.get('/api/admin/logout', (req, res) => {
    res.redirect('/');
  });



  // Employee authentication routes
  app.post('/api/employee/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const employee = await storage.validateEmployeePassword(email, password);
      if (!employee) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ employeeId: employee.id }, JWT_SECRET, { expiresIn: '8h' });
      
      res.json({
        token,
        employee: {
          id: employee.id,
          email: employee.email,
          firstName: employee.firstName,
          lastName: employee.lastName,
          profileImageUrl: employee.profileImageUrl,
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.get('/api/employee/me', authenticateEmployee, (req: any, res) => {
    res.json({
      id: req.employee.id,
      email: req.employee.email,
      firstName: req.employee.firstName,
      lastName: req.employee.lastName,
      profileImageUrl: req.employee.profileImageUrl,
    });
  });



  // Admin authentication middleware
  const authenticateAdmin = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return res.status(401).json({ message: 'Access token required' });
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      console.log('Admin token decoded:', decoded);
      if (!decoded.adminId) {
        return res.status(401).json({ message: 'Invalid admin token' });
      }
      req.adminId = decoded.adminId;
      next();
    } catch (error) {
      console.error('Admin token verification error:', error);
      return res.status(401).json({ message: 'Invalid token' });
    }
  };

  app.get('/api/admin/me', authenticateAdmin, async (req: any, res) => {
    try {
      const admin = await storage.getAdminUser(req.adminId);
      if (!admin) {
        return res.status(404).json({ message: 'Admin not found' });
      }
      res.json({
        id: admin.id,
        email: admin.email,
        firstName: admin.firstName,
        lastName: admin.lastName,
        profileImageUrl: admin.profileImageUrl,
      });
    } catch (error) {
      console.error('Get admin error:', error);
      res.status(500).json({ message: 'Failed to get admin' });
    }
  });

  app.post('/api/admin/logout', (req, res) => {
    res.json({ message: "Logged out successfully" });
  });

  app.post('/api/employee/logout', (req, res) => {
    res.json({ message: "Logged out successfully" });
  });

  // Employee registration route (admin only)
  app.post('/api/admin/employees', authenticateAdmin, async (req, res) => {
    try {
      const employeeData = req.body;
      
      // Validate required fields
      if (!employeeData.email || !employeeData.password || !employeeData.firstName || !employeeData.lastName) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Check if employee already exists
      const existingEmployee = await storage.getEmployeeByEmail(employeeData.email);
      if (existingEmployee) {
        return res.status(400).json({ message: "Employee with this email already exists" });
      }

      const employee = await storage.createEmployee(employeeData);
      
      // Return employee without password
      res.status(201).json({
        id: employee.id,
        email: employee.email,
        firstName: employee.firstName,
        lastName: employee.lastName,
        profileImageUrl: employee.profileImageUrl,
        isActive: employee.isActive,
        hourlyRate: employee.hourlyRate,
        createdAt: employee.createdAt,
        updatedAt: employee.updatedAt
      });
    } catch (error) {
      console.error('Employee creation error:', error);
      res.status(500).json({ message: "Failed to create employee" });
    }
  });

  // Work session routes
  app.post('/api/employee/clock-in', authenticateEmployee, async (req: any, res) => {
    try {
      const session = await storage.clockIn(req.employee.id);
      res.json(session);
    } catch (error) {
      console.error('Clock in error:', error);
      res.status(500).json({ message: "Clock in failed" });
    }
  });

  app.post('/api/employee/clock-out', authenticateEmployee, async (req: any, res) => {
    try {
      const session = await storage.clockOut(req.employee.id);
      if (!session) {
        return res.status(400).json({ message: "No active session to clock out" });
      }
      res.json(session);
    } catch (error) {
      console.error('Clock out error:', error);
      res.status(500).json({ message: "Clock out failed" });
    }
  });

  app.post('/api/employee/toggle-break', authenticateEmployee, async (req: any, res) => {
    try {
      const session = await storage.toggleBreak(req.employee.id);
      res.json(session);
    } catch (error) {
      console.error('Toggle break error:', error);
      res.status(500).json({ message: "Toggle break failed" });
    }
  });

  app.get('/api/employee/current-session', authenticateEmployee, async (req: any, res) => {
    try {
      const session = await storage.getCurrentWorkSession(req.employee.id);
      res.json(session);
    } catch (error) {
      console.error('Get current session error:', error);
      res.status(500).json({ message: "Failed to get current session" });
    }
  });

  // Dashboard data routes
  app.get('/api/employee/stats', authenticateEmployee, async (req: any, res) => {
    try {
      const stats = await storage.getEmployeeStats(req.employee.id);
      res.json(stats);
    } catch (error) {
      console.error('Get stats error:', error);
      res.status(500).json({ message: "Failed to get stats" });
    }
  });

  app.get('/api/employee/queue', authenticateEmployee, async (req: any, res) => {
    try {
      const conversations = await storage.getWaitingConversations();
      res.json(conversations);
    } catch (error) {
      console.error('Get queue error:', error);
      res.status(500).json({ message: "Failed to get queue" });
    }
  });

  app.post('/api/employee/pickup-chat/:conversationId', authenticateEmployee, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const conversation = await storage.assignConversationToEmployee(conversationId, req.employee.id);
      
      if (!conversation) {
        return res.status(404).json({ message: "Chat not found or already assigned" });
      }
      
      res.json(conversation);
    } catch (error) {
      console.error('Pickup chat error:', error);
      res.status(500).json({ message: "Failed to pickup chat" });
    }
  });

  app.get('/api/employee/active-chats', authenticateEmployee, async (req: any, res) => {
    try {
      const conversations = await storage.getActiveConversationsForEmployee(req.employee.id);
      res.json(conversations);
    } catch (error) {
      console.error('Get active chats error:', error);
      res.status(500).json({ message: "Failed to get active chats" });
    }
  });

  app.get('/api/employee/recent-conversations', authenticateEmployee, async (req: any, res) => {
    try {
      const conversations = await storage.getRecentConversationsForEmployee(req.employee.id, 10);
      res.json(conversations);
    } catch (error) {
      console.error('Get recent conversations error:', error);
      res.status(500).json({ message: "Failed to get recent conversations" });
    }
  });

  app.get('/api/employee/earnings', authenticateEmployee, async (req: any, res) => {
    try {
      const earnings = await storage.getEarningsBreakdownForEmployee(req.employee.id, 20);
      res.json(earnings);
    } catch (error) {
      console.error('Get earnings error:', error);
      res.status(500).json({ message: "Failed to get earnings" });
    }
  });

  // Activity logging routes
  app.get('/api/employee/activity-logs', authenticateEmployee, async (req: any, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit) : 50;
      const logs = await storage.getActivityLogsForEmployee(req.employee.id, limit);
      res.json(logs);
    } catch (error) {
      console.error('Get activity logs error:', error);
      res.status(500).json({ message: "Failed to get activity logs" });
    }
  });

  app.get('/api/employee/session-logs/:sessionId', authenticateEmployee, async (req: any, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const logs = await storage.getActivityLogsForSession(req.employee.id, sessionId);
      res.json(logs);
    } catch (error) {
      console.error('Get session logs error:', error);
      res.status(500).json({ message: "Failed to get session logs" });
    }
  });

  // Tracking lookup for agents - correlates with AI customer data
  app.get('/api/tracking/:orderNumber', authenticateEmployee, async (req, res) => {
    try {
      const { orderNumber } = req.params;
      
      // Find the AI customer who has this order number
      const aiCustomers = await storage.getAllAiCustomers();
      const customer = aiCustomers.find(c => c.orderNumber === orderNumber);
      
      if (!customer) {
        return res.status(404).json({ 
          error: "Order not found",
          message: "No order found with that number in our system" 
        });
      }
      
      // Use the customer's actual service type and tracking status
      const serviceType = customer.serviceType;
      const currentStatus = customer.trackingStatus;
      
      const trackingStatuses = {
        'game_development': ['requirements_gathering', 'code_development', 'testing_phase', 'debugging', 'optimization', 'final_review'],
        'bot_development': ['bot_configuration', 'feature_implementation', 'testing_commands', 'integration_testing', 'deployment_prep'],
        '3d_modeling': ['concept_design', 'base_modeling', 'texturing', 'rigging', 'quality_assurance'],
        'ui_design': ['wireframe_creation', 'design_mockups', 'responsive_design', 'user_testing', 'final_polish'],
        'animation': ['storyboard_creation', 'keyframe_animation', 'rendering', 'post_processing', 'final_export'],
        'sound_design': ['audio_recording', 'sound_editing', 'mixing', 'mastering', 'format_delivery'],
        'web_development': ['frontend_development', 'backend_setup', 'database_integration', 'testing', 'deployment']
      };
      
      const statuses = trackingStatuses[serviceType] || trackingStatuses['game_development'];
      const currentStatusIndex = statuses.indexOf(currentStatus);
      const progress = currentStatusIndex >= 0 ? Math.min(95, (currentStatusIndex + 1) * (100 / statuses.length)) : 25;
      
      // Generate realistic completion time based on service type and current progress
      const hoursRemaining = serviceType === 'game_development' ? 24 + Math.random() * 48 :
                            serviceType === 'bot_development' ? 12 + Math.random() * 24 :
                            serviceType === '3d_modeling' ? 18 + Math.random() * 36 :
                            serviceType === 'ui_design' ? 8 + Math.random() * 16 :
                            serviceType === 'animation' ? 20 + Math.random() * 40 :
                            serviceType === 'sound_design' ? 6 + Math.random() * 12 :
                            16 + Math.random() * 32;
      
      const trackingInfo = {
        orderNumber,
        customerName: customer.name,
        customerEmail: customer.email,
        serviceType: customer.serviceType,
        status: currentStatus,
        progress: Math.round(progress),
        estimatedCompletion: new Date(Date.now() + hoursRemaining * 60 * 60 * 1000).toISOString(),
        lastUpdated: new Date(Date.now() - Math.random() * 6 * 60 * 60 * 1000).toISOString(),
        assignedTeam: serviceType === 'game_development' ? 'Game Dev Team Alpha' :
                     serviceType === 'bot_development' ? 'Bot Development Team Beta' :
                     serviceType === '3d_modeling' ? 'Modeling Team Gamma' :
                     serviceType === 'ui_design' ? 'Design Team Delta' :
                     serviceType === 'animation' ? 'Animation Team Epsilon' :
                     serviceType === 'sound_design' ? 'Audio Team Zeta' : 'Web Dev Team Eta',
        priority: customer.customerType === 'premium' ? 'High' : 'Standard',
        notes: `Customer type: ${customer.customerType}, Personality: ${customer.personalityType}`
      };
      
      res.json(trackingInfo);
    } catch (error) {
      console.error("Error fetching tracking info:", error);
      res.status(500).json({ message: "Failed to fetch tracking information" });
    }
  });

  // POST route for tracking lookup (used by frontend)
  app.post('/api/employee/tracking-lookup', authenticateEmployee, async (req: any, res) => {
    try {
      const { orderNumber } = req.body;
      
      if (!orderNumber) {
        return res.status(400).json({ 
          error: "Missing order number",
          message: "Please provide an order number to lookup" 
        });
      }
      
      // Find the AI customer who has this order number
      const aiCustomers = await storage.getAllAiCustomers();
      const customer = aiCustomers.find(c => c.orderNumber === orderNumber);
      
      if (!customer) {
        return res.status(404).json({ 
          error: "Order not found",
          message: "No order found with that number in our system" 
        });
      }
      
      // Use the customer's actual service type and tracking status
      const serviceType = customer.serviceType;
      const currentStatus = customer.trackingStatus;
      
      const trackingStatuses = {
        'game_development': ['requirements_gathering', 'code_development', 'testing_phase', 'debugging', 'optimization', 'final_review'],
        'bot_development': ['bot_configuration', 'feature_implementation', 'testing_commands', 'integration_testing', 'deployment_prep'],
        '3d_modeling': ['concept_design', 'base_modeling', 'texturing', 'rigging', 'quality_assurance'],
        'ui_design': ['wireframe_creation', 'design_mockups', 'responsive_design', 'user_testing', 'final_polish'],
        'animation': ['storyboard_creation', 'keyframe_animation', 'rendering', 'post_processing', 'final_export'],
        'sound_design': ['audio_recording', 'sound_editing', 'mixing', 'mastering', 'format_delivery'],
        'web_development': ['frontend_development', 'backend_setup', 'database_integration', 'testing', 'deployment']
      };
      
      const statuses = trackingStatuses[serviceType] || trackingStatuses['game_development'];
      const currentStatusIndex = statuses.indexOf(currentStatus);
      const progress = currentStatusIndex >= 0 ? Math.min(95, (currentStatusIndex + 1) * (100 / statuses.length)) : 25;
      
      // Generate realistic completion time based on service type and current progress
      const hoursRemaining = serviceType === 'game_development' ? 24 + Math.random() * 48 :
                            serviceType === 'bot_development' ? 12 + Math.random() * 24 :
                            serviceType === '3d_modeling' ? 18 + Math.random() * 36 :
                            serviceType === 'ui_design' ? 8 + Math.random() * 16 :
                            serviceType === 'animation' ? 20 + Math.random() * 40 :
                            serviceType === 'sound_design' ? 6 + Math.random() * 12 :
                            16 + Math.random() * 32;
      
      const trackingInfo = {
        orderNumber,
        customerName: customer.name,
        customerEmail: customer.email,
        serviceType: customer.serviceType,
        status: currentStatus,
        progress: Math.round(progress),
        estimatedCompletion: new Date(Date.now() + hoursRemaining * 60 * 60 * 1000).toISOString(),
        lastUpdated: new Date(Date.now() - Math.random() * 6 * 60 * 60 * 1000).toISOString(),
        assignedTeam: serviceType === 'game_development' ? 'Game Dev Team Alpha' :
                     serviceType === 'bot_development' ? 'Bot Development Team Beta' :
                     serviceType === '3d_modeling' ? 'Modeling Team Gamma' :
                     serviceType === 'ui_design' ? 'Design Team Delta' :
                     serviceType === 'animation' ? 'Animation Team Epsilon' :
                     serviceType === 'sound_design' ? 'Audio Team Zeta' : 'Web Dev Team Eta',
        priority: customer.customerType === 'premium' ? 'High' : 'Standard',
        notes: `Customer type: ${customer.customerType}, Personality: ${customer.personalityType}`
      };
      
      res.json(trackingInfo);
    } catch (error) {
      console.error("Error fetching tracking info:", error);
      res.status(500).json({ message: "Failed to fetch tracking information" });
    }
  });

  // Pickup chat
  app.post('/api/employee/pickup-chat/:conversationId', authenticateEmployee, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const conversation = await storage.assignConversationToEmployee(conversationId, req.employee.id);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found or already assigned" });
      }

      res.json(conversation);
    } catch (error) {
      console.error('Pickup chat error:', error);
      res.status(500).json({ message: "Failed to pickup chat" });
    }
  });

  // Get conversation details
  app.get('/api/conversation/:id', authenticateEmployee, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const conversation = await storage.getConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      res.json(conversation);
    } catch (error) {
      console.error('Get conversation error:', error);
      res.status(500).json({ message: "Failed to get conversation" });
    }
  });

  app.get('/api/conversation/:id/messages', authenticateEmployee, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getMessagesForConversation(conversationId);
      res.json(messages);
    } catch (error) {
      console.error('Get messages error:', error);
      res.status(500).json({ message: "Failed to get messages" });
    }
  });

  // Admin routes (simplified for now)
  app.get('/api/admin/stats', async (req, res) => {
    try {
      const stats = await storage.getAllEmployeeStats();
      res.json(stats);
    } catch (error) {
      console.error('Get admin stats error:', error);
      res.status(500).json({ message: "Failed to get admin stats" });
    }
  });

  app.get('/api/admin/employees', async (req, res) => {
    try {
      const employees = await storage.getAllEmployees();
      res.json(employees);
    } catch (error) {
      console.error('Get employees error:', error);
      res.status(500).json({ message: "Failed to get employees" });
    }
  });

  app.post('/api/admin/employees', async (req, res) => {
    try {
      const employeeData = insertEmployeeSchema.parse(req.body);
      const employee = await storage.createEmployee({
        ...employeeData,
        password: req.body.password,
      });
      res.json(employee);
    } catch (error) {
      console.error('Create employee error:', error);
      res.status(500).json({ message: "Failed to create employee" });
    }
  });

  app.get('/api/admin/employee-stats/:employeeId', authenticateAdmin, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const stats = await storage.getEmployeeStats(employeeId);
      res.json(stats);
    } catch (error) {
      console.error('Error fetching employee stats:', error);
      res.status(500).json({ message: "Failed to fetch employee stats" });
    }
  });

  app.get('/api/admin/employee-session/:employeeId', authenticateAdmin, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const session = await storage.getCurrentWorkSession(employeeId);
      res.json(session || {});
    } catch (error) {
      console.error('Error fetching employee session:', error);
      res.status(500).json({ message: "Failed to fetch employee session" });
    }
  });

  app.get('/api/admin/employee-conversations/:employeeId', authenticateAdmin, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const conversations = await storage.getRecentConversationsForEmployee(employeeId, 10);
      res.json(conversations);
    } catch (error) {
      console.error('Error fetching employee conversations:', error);
      res.status(500).json({ message: "Failed to fetch employee conversations" });
    }
  });

  app.post('/api/admin/create-conversation', async (req, res) => {
    try {
      const customer = await storage.getRandomAiCustomer();
      if (!customer) {
        return res.status(404).json({ message: "No AI customers available" });
      }
      
      const issuePreview = generateIssuePreview(customer.serviceType || 'general', customer.customerType);
      
      const conversation = await storage.createConversation({
        aiCustomerId: customer.id,
        chatNumber: `#${Date.now().toString().slice(-6)}`,
        status: 'waiting',
        issuePreview: issuePreview,
      });

      res.json(conversation);
    } catch (error) {
      console.error('Create conversation error:', error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  // Enhanced customer generation system: Every 2-3 minutes, 30% chance for 2 customers
  function scheduleNextCustomer() {
    const minInterval = 120000; // 2 minutes
    const maxInterval = 180000; // 3 minutes
    const nextInterval = Math.random() * (maxInterval - minInterval) + minInterval;
    
    setTimeout(async () => {
      try {
        // 30% chance to create 2 customers at once
        const createTwo = Math.random() < 0.3;
        const customersToCreate = createTwo ? 2 : 1;
        
        for (let i = 0; i < customersToCreate; i++) {
          const customer = await storage.getRandomAiCustomer();
          if (customer) {
            // Create conversation with random start time (up to 15 minutes ago for realism)
            const randomMinutesAgo = Math.floor(Math.random() * 15);
            const startTime = new Date(Date.now() - (randomMinutesAgo * 60000));
            
            const issuePreview = generateIssuePreview(customer.serviceType || 'general', customer.customerType);
            
            // Slight delay between creating multiple customers (0-10 seconds)
            const creationDelay = i > 0 ? Math.random() * 10000 : 0;
            
            setTimeout(async () => {
              const conversation = await storage.createConversation({
                aiCustomerId: customer.id,
                chatNumber: `#${Date.now().toString().slice(-6)}`,
                status: 'waiting',
                issuePreview: issuePreview,
              });

              // Update the conversation start time to simulate realistic delays
              await storage.updateConversationStartTime(conversation.id, startTime);

              // Add initial system message explaining the delay if there was one
              if (randomMinutesAgo > 0) {
                const delayReasons = [
                  "Previous agent encountered technical difficulties",
                  "Customer was transferred from another department",
                  "System experienced temporary connectivity issues", 
                  "Customer was waiting in high-priority queue",
                  "Previous agent had to escalate to specialist team",
                  "Customer was on hold while verifying account information",
                  "Network latency caused initial connection delay"
                ];
                
                const reason = delayReasons[Math.floor(Math.random() * delayReasons.length)];
                await storage.createMessage({
                  conversationId: conversation.id,
                  senderType: 'system',
                  content: `Customer has been waiting ${randomMinutesAgo} minutes. Reason: ${reason}.`,
                });
              }
            }, creationDelay);
          }
        }
        
        if (createTwo) {
          console.log('Generated 2 customers simultaneously');
        }
      } catch (error) {
        console.error('Error creating periodic conversation:', error);
      }
      
      // Schedule the next customer batch
      scheduleNextCustomer();
    }, nextInterval);
  }

  // Start the customer generation cycle
  scheduleNextCustomer();

  // Customer abandonment system - customers leave if waiting too long
  setInterval(async () => {
    try {
      const waitingConversations = await storage.getWaitingConversations();
      
      for (const conversation of waitingConversations) {
        const waitTime = Date.now() - new Date(conversation.startedAt || new Date()).getTime();
        const waitMinutes = waitTime / (1000 * 60);
        
        // Abandonment probability increases with wait time
        let abandonmentChance = 0;
        if (waitMinutes > 3) abandonmentChance = 0.05; // 5% after 3 minutes
        if (waitMinutes > 5) abandonmentChance = 0.15; // 15% after 5 minutes
        if (waitMinutes > 8) abandonmentChance = 0.30; // 30% after 8 minutes
        if (waitMinutes > 12) abandonmentChance = 0.50; // 50% after 12 minutes
        if (waitMinutes > 20) abandonmentChance = 0.80; // 80% after 20 minutes
        
        if (Math.random() < abandonmentChance) {
          // Customer leaves - mark conversation as abandoned
          await storage.completeConversation(conversation.id, undefined, undefined, true);
          
          // Add system message about abandonment
          await storage.createMessage({
            conversationId: conversation.id,
            senderType: 'system',
            content: `Customer left the chat after waiting ${Math.floor(waitMinutes)} minutes.`,
          });
          
          console.log(`Customer ${conversation.aiCustomer.name} abandoned chat after ${Math.floor(waitMinutes)} minutes`);
        }
      }
    } catch (error) {
      console.error('Error processing customer abandonment:', error);
    }
  }, 30000); // Check every 30 seconds

  // Initialize AI customers if none exist
  setTimeout(async () => {
    try {
      const existingCustomers = await storage.getAllAiCustomers();
      if (existingCustomers.length === 0) {
        console.log('Creating initial AI customers...');
        for (let i = 0; i < 10; i++) {
          const customerData = await generateAICustomer();
          await storage.createAiCustomer({
            name: customerData.name,
            email: customerData.email,
            location: customerData.location,
            customerType: customerData.customerType,
            personalityType: customerData.personalityType,
            profileImageUrl: customerData.profileImageUrl,
            avgRating: customerData.avgRating ? customerData.avgRating.toString() : null,
            serviceType: customerData.serviceType,
            orderNumber: customerData.orderNumber,
            trackingStatus: customerData.trackingStatus,
          });
        }
        console.log('Initial AI customers created');
      }
    } catch (error) {
      console.error('Error creating initial AI customers:', error);
    }
  }, 2000);

  return httpServer;
}
