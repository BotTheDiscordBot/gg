// Generate realistic issue previews based on service types
export function generateIssuePreview(serviceType: string, customerType: string): string {
  const issues = {
    game_script: [
      "NPC dialogue not triggering correctly",
      "Player inventory system has duplication bug",
      "Quest completion script failing at 50%",
      "Character movement feels sluggish",
      "Save/load system corrupting player data",
      "Multiplayer sync issues with game state",
      "Boss AI getting stuck in attack loop",
      "UI elements overlapping in mobile view",
      "Audio cues not playing during cutscenes",
      "Performance drops during large battles"
    ],
    "3d_model": [
      "Model textures appearing pixelated",
      "Rigging issues with character animations",
      "Model poly count too high for mobile",
      "UV mapping errors on complex surfaces",
      "Lighting not working properly on model",
      "Model clipping through environment",
      "Animation export missing keyframes",
      "Materials not rendering in engine",
      "Model scale incorrect for game world",
      "Bone weights causing mesh deformation"
    ],
    ui_design: [
      "Button hover states not working",
      "Menu navigation confusing for users",
      "Text readability issues on mobile",
      "Color contrast not meeting accessibility",
      "Layout breaking on different screen sizes",
      "Icons not loading properly",
      "Form validation messages unclear",
      "Loading animations too slow",
      "Modal windows not responsive",
      "Dropdown menus cutting off content"
    ],
    animation: [
      "Character walk cycle looks unnatural",
      "Facial expressions not syncing with audio",
      "Animation transitions too abrupt",
      "Keyframe timing needs adjustment",
      "Particle effects not matching concept",
      "Camera movements causing motion sickness",
      "Animation loops have visible seams",
      "Character lip sync out of timing",
      "Environmental animations stuttering",
      "Combat animations lack impact feeling"
    ],
    sound_effect: [
      "Audio cutting out during gameplay",
      "Sound effects too loud compared to music",
      "Footstep sounds not matching surface type",
      "Weapon sounds lack punch and impact",
      "Environmental audio not looping smoothly",
      "Voice acting has background noise",
      "Audio compression causing artifacts",
      "Sound delay in multiplayer sessions",
      "Missing audio cues for important events",
      "Spatial audio not working correctly"
    ],
    music_track: [
      "Background music overpowering dialogue",
      "Track doesn't loop seamlessly",
      "Music doesn't match game mood/theme",
      "Audio quality lower than expected",
      "Track length needs to be extended",
      "Missing dynamic music transitions",
      "Instruments sound too synthetic",
      "Beat doesn't match gameplay rhythm",
      "Audio mixing levels inconsistent",
      "Music stops abruptly during scene changes"
    ],
    bot_setup: [
      "Bot not responding to user commands",
      "Setup instructions unclear or missing",
      "Bot permissions not configured correctly",
      "Integration with game engine failing",
      "Bot responses seem random or off-topic",
      "Performance issues during peak usage",
      "Bot crashing when handling large requests",
      "API rate limits being exceeded",
      "Database connection errors",
      "Authentication system not working"
    ]
  };

  const serviceIssues = issues[serviceType as keyof typeof issues] || [
    "Need help with order status",
    "Technical issue needs resolution",
    "Quality doesn't match expectations",
    "Delivery delay concerns",
    "Billing question about recent order"
  ];

  const randomIssue = serviceIssues[Math.floor(Math.random() * serviceIssues.length)];
  
  // Add urgency modifiers based on customer type
  const urgencyModifiers = {
    "VIP": ["URGENT: ", "PRIORITY: "],
    "Premium": ["Important: "],
    "Frustrated": ["HELP NEEDED: "],
    "Angry": ["URGENT ISSUE: "],
    default: [""]
  };

  const modifiers = urgencyModifiers[customerType as keyof typeof urgencyModifiers] || urgencyModifiers.default;
  const modifier = modifiers[Math.floor(Math.random() * modifiers.length)];

  return `${modifier}${randomIssue}`;
}