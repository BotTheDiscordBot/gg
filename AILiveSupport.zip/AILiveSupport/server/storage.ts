import {
  employees,
  adminUsers,
  workSessions,
  aiCustomers,
  conversations,
  messages,
  earnings,
  activityLogs,
  type Employee,
  type InsertEmployee,
  type AdminUser,
  type UpsertAdminUser,
  type WorkSession,
  type InsertWorkSession,
  type AiCustomer,
  type Conversation,
  type InsertConversation,
  type Message,
  type InsertMessage,
  type Earnings,
  type InsertEarnings,
  type ActivityLog,
  type InsertActivityLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, isNull, count, sum, avg } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // Admin operations (for Replit Auth)
  getAdminUser(id: string): Promise<AdminUser | undefined>;
  upsertAdminUser(user: UpsertAdminUser): Promise<AdminUser>;

  // Employee operations
  getEmployee(id: number): Promise<Employee | undefined>;
  getEmployeeByEmail(email: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee & { password: string }): Promise<Employee>;
  validateEmployeePassword(email: string, password: string): Promise<Employee | null>;
  getAllEmployees(): Promise<Employee[]>;
  updateEmployee(id: number, updates: Partial<Employee>): Promise<Employee | undefined>;

  // Work session operations
  clockIn(employeeId: number): Promise<WorkSession>;
  clockOut(employeeId: number): Promise<WorkSession | undefined>;
  getCurrentWorkSession(employeeId: number): Promise<WorkSession | undefined>;
  toggleBreak(employeeId: number): Promise<WorkSession | undefined>;
  getWorkSessionsForEmployee(employeeId: number, limit?: number): Promise<WorkSession[]>;

  // AI Customer operations
  getAllAiCustomers(): Promise<AiCustomer[]>;
  getRandomAiCustomer(): Promise<AiCustomer | undefined>;
  createAiCustomer(customer: Omit<AiCustomer, 'id' | 'createdAt'>): Promise<AiCustomer>;

  // Conversation operations
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversation(id: number): Promise<(Conversation & { aiCustomer: AiCustomer }) | undefined>;
  getWaitingConversations(): Promise<(Conversation & { aiCustomer: AiCustomer })[]>;
  getActiveConversationsForEmployee(employeeId: number): Promise<(Conversation & { aiCustomer: AiCustomer })[]>;
  assignConversationToEmployee(conversationId: number, employeeId: number): Promise<Conversation | undefined>;
  completeConversation(conversationId: number, rating?: number, review?: string, wasAbandoned?: boolean): Promise<Conversation | undefined>;
  getRecentConversationsForEmployee(employeeId: number, limit?: number): Promise<(Conversation & { aiCustomer: AiCustomer })[]>;
  updateConversationStartTime(conversationId: number, startTime: Date): Promise<void>;

  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesForConversation(conversationId: number): Promise<Message[]>;

  // Earnings operations
  createEarning(earning: InsertEarnings): Promise<Earnings>;
  getTodayEarningsForEmployee(employeeId: number): Promise<number>;
  getEarningsBreakdownForEmployee(employeeId: number, limit?: number): Promise<(Earnings & { conversation?: Conversation })[]>;
  getEmployeeStats(employeeId: number): Promise<{
    todayEarnings: number;
    todayConversations: number;
    averageRating: number;
    totalEarnings: number;
  }>;

  // Analytics for admin
  getAllEmployeeStats(): Promise<{
    totalEmployees: number;
    activeEmployees: number;
    totalConversations: number;
    averageRating: number;
    totalEarnings: number;
  }>;

  // Activity logging operations
  logActivity(employeeId: number, activityType: string, description: string, metadata?: any): Promise<ActivityLog>;
  getActivityLogsForEmployee(employeeId: number, limit?: number): Promise<ActivityLog[]>;
  getActivityLogsForSession(employeeId: number, sessionId: number): Promise<ActivityLog[]>;
}

export class DatabaseStorage implements IStorage {
  // Admin operations
  async getAdminUser(id: string): Promise<AdminUser | undefined> {
    const [user] = await db.select().from(adminUsers).where(eq(adminUsers.id, id));
    return user;
  }

  async upsertAdminUser(userData: UpsertAdminUser): Promise<AdminUser> {
    const [user] = await db
      .insert(adminUsers)
      .values(userData)
      .onConflictDoUpdate({
        target: adminUsers.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Employee operations
  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee;
  }

  async getEmployeeByEmail(email: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.email, email));
    return employee;
  }

  async createEmployee(employeeData: InsertEmployee & { password: string }): Promise<Employee> {
    const hashedPassword = await bcrypt.hash(employeeData.password, 10);
    const [employee] = await db
      .insert(employees)
      .values({
        ...employeeData,
        password: hashedPassword,
      })
      .returning();
    return employee;
  }

  async validateEmployeePassword(email: string, password: string): Promise<Employee | null> {
    const employee = await this.getEmployeeByEmail(email);
    if (!employee) return null;

    const isValid = await bcrypt.compare(password, employee.password);
    return isValid ? employee : null;
  }

  async getAllEmployees(): Promise<Employee[]> {
    return await db.select().from(employees).orderBy(desc(employees.createdAt));
  }

  async updateEmployee(id: number, updates: Partial<Employee>): Promise<Employee | undefined> {
    const [employee] = await db
      .update(employees)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(employees.id, id))
      .returning();
    return employee;
  }

  // Work session operations
  async clockIn(employeeId: number): Promise<WorkSession> {
    // End any existing session first
    await db
      .update(workSessions)
      .set({ clockOutTime: new Date() })
      .where(and(eq(workSessions.employeeId, employeeId), isNull(workSessions.clockOutTime)));

    const clockInTime = new Date();
    const [session] = await db
      .insert(workSessions)
      .values({
        employeeId,
        clockInTime,
      })
      .returning();

    // Log the clock in activity
    await this.logActivity(employeeId, 'CLOCK_IN', 'Clocked in for work shift', {
      sessionId: session.id,
      clockInTime: clockInTime,
    });

    return session;
  }

  async clockOut(employeeId: number): Promise<WorkSession | undefined> {
    const currentSession = await this.getCurrentWorkSession(employeeId);
    if (!currentSession) return undefined;

    // Prevent clocking out if already clocked out
    if (currentSession.clockOutTime) return currentSession;

    const clockOutTime = new Date();
    const [session] = await db
      .update(workSessions)
      .set({ 
        clockOutTime,
        isOnBreak: false, // End any active break
      })
      .where(eq(workSessions.id, currentSession.id))
      .returning();

    // Log the clock out activity
    await this.logActivity(employeeId, 'CLOCK_OUT', 'Clocked out for the day', {
      sessionId: session.id,
      clockInTime: session.clockInTime,
      clockOutTime: clockOutTime,
    });

    return session;
  }

  async getCurrentWorkSession(employeeId: number): Promise<WorkSession | undefined> {
    const [session] = await db
      .select()
      .from(workSessions)
      .where(and(eq(workSessions.employeeId, employeeId), isNull(workSessions.clockOutTime)))
      .orderBy(desc(workSessions.clockInTime))
      .limit(1);
    return session;
  }

  async toggleBreak(employeeId: number): Promise<WorkSession | undefined> {
    const session = await this.getCurrentWorkSession(employeeId);
    if (!session) return undefined;

    if (session.isOnBreak) {
      // End break
      const breakEndTime = new Date();
      const [updated] = await db
        .update(workSessions)
        .set({
          isOnBreak: false,
          breakStartTime: null,
        })
        .where(eq(workSessions.id, session.id))
        .returning();

      // Log break end activity
      await this.logActivity(employeeId, 'BREAK_END', 'Returned from break', {
        sessionId: session.id,
        breakEndTime: breakEndTime,
        breakStartTime: session.breakStartTime,
      });

      return updated;
    } else {
      // Start break
      const breakStartTime = new Date();
      const [updated] = await db
        .update(workSessions)
        .set({
          isOnBreak: true,
          breakStartTime,
        })
        .where(eq(workSessions.id, session.id))
        .returning();

      // Log break start activity
      await this.logActivity(employeeId, 'BREAK_START', 'Started break', {
        sessionId: session.id,
        breakStartTime: breakStartTime,
      });

      return updated;
    }
  }

  async getWorkSessionsForEmployee(employeeId: number, limit = 10): Promise<WorkSession[]> {
    return await db
      .select()
      .from(workSessions)
      .where(eq(workSessions.employeeId, employeeId))
      .orderBy(desc(workSessions.clockInTime))
      .limit(limit);
  }

  // AI Customer operations
  async getAllAiCustomers(): Promise<AiCustomer[]> {
    return await db.select().from(aiCustomers);
  }

  async getRandomAiCustomer(): Promise<AiCustomer | undefined> {
    const customers = await db.select().from(aiCustomers);
    if (customers.length === 0) return undefined;
    return customers[Math.floor(Math.random() * customers.length)];
  }

  async createAiCustomer(customerData: Omit<AiCustomer, 'id' | 'createdAt'>): Promise<AiCustomer> {
    const [customer] = await db
      .insert(aiCustomers)
      .values(customerData)
      .returning();
    return customer;
  }

  // Conversation operations
  async createConversation(conversationData: InsertConversation): Promise<Conversation> {
    const chatNumber = `#${Date.now().toString().slice(-6)}`;
    const [conversation] = await db
      .insert(conversations)
      .values({
        ...conversationData,
        chatNumber,
      })
      .returning();
    return conversation;
  }

  async getConversation(id: number): Promise<(Conversation & { aiCustomer: AiCustomer }) | undefined> {
    const [conversation] = await db
      .select({
        id: conversations.id,
        employeeId: conversations.employeeId,
        aiCustomerId: conversations.aiCustomerId,
        chatNumber: conversations.chatNumber,
        status: conversations.status,
        issuePreview: conversations.issuePreview,
        startedAt: conversations.startedAt,
        completedAt: conversations.completedAt,
        totalMinutes: conversations.totalMinutes,
        customerRating: conversations.customerRating,
        customerReview: conversations.customerReview,
        earnings: conversations.earnings,
        wasAbandoned: conversations.wasAbandoned,
        aiCustomer: aiCustomers,
      })
      .from(conversations)
      .innerJoin(aiCustomers, eq(conversations.aiCustomerId, aiCustomers.id))
      .where(eq(conversations.id, id));
    return conversation;
  }

  async getWaitingConversations(): Promise<(Conversation & { aiCustomer: AiCustomer })[]> {
    return await db
      .select({
        id: conversations.id,
        employeeId: conversations.employeeId,
        aiCustomerId: conversations.aiCustomerId,
        chatNumber: conversations.chatNumber,
        status: conversations.status,
        issuePreview: conversations.issuePreview,
        startedAt: conversations.startedAt,
        completedAt: conversations.completedAt,
        totalMinutes: conversations.totalMinutes,
        customerRating: conversations.customerRating,
        customerReview: conversations.customerReview,
        earnings: conversations.earnings,
        wasAbandoned: conversations.wasAbandoned,
        aiCustomer: aiCustomers,
      })
      .from(conversations)
      .innerJoin(aiCustomers, eq(conversations.aiCustomerId, aiCustomers.id))
      .where(eq(conversations.status, "waiting"))
      .orderBy(conversations.startedAt);
  }

  async getActiveConversationsForEmployee(employeeId: number): Promise<(Conversation & { aiCustomer: AiCustomer })[]> {
    return await db
      .select({
        id: conversations.id,
        employeeId: conversations.employeeId,
        aiCustomerId: conversations.aiCustomerId,
        chatNumber: conversations.chatNumber,
        status: conversations.status,
        issuePreview: conversations.issuePreview,
        startedAt: conversations.startedAt,
        completedAt: conversations.completedAt,
        totalMinutes: conversations.totalMinutes,
        customerRating: conversations.customerRating,
        customerReview: conversations.customerReview,
        earnings: conversations.earnings,
        wasAbandoned: conversations.wasAbandoned,
        aiCustomer: aiCustomers,
      })
      .from(conversations)
      .innerJoin(aiCustomers, eq(conversations.aiCustomerId, aiCustomers.id))
      .where(and(eq(conversations.employeeId, employeeId), eq(conversations.status, "active")))
      .orderBy(conversations.startedAt);
  }

  async assignConversationToEmployee(conversationId: number, employeeId: number): Promise<Conversation | undefined> {
    const assignedAt = new Date();
    const [conversation] = await db
      .update(conversations)
      .set({
        employeeId,
        status: "active",
      })
      .where(eq(conversations.id, conversationId))
      .returning();

    // Create initial AI customer message if conversation was successfully assigned
    if (conversation) {
      // Get customer info for logging
      const customerInfo = await db
        .select()
        .from(aiCustomers)
        .where(eq(aiCustomers.id, conversation.aiCustomerId))
        .limit(1);

      // Log chat pickup activity
      await this.logActivity(employeeId, 'CHAT_PICKED_UP', `Picked up chat with ${customerInfo[0]?.name || 'customer'}`, {
        conversationId: conversation.id,
        chatNumber: conversation.chatNumber,
        customerName: customerInfo[0]?.name,
        customerType: customerInfo[0]?.customerType,
        serviceType: customerInfo[0]?.serviceType,
        assignedAt: assignedAt,
      });
      // First message is always the security notice
      await this.createMessage({
        conversationId: conversation.id,
        senderType: "system",
        content: "This conversation may be archived and saved for security purposes.",
      });

      // Then add a realistic opening message
      const initialMessages = [
        "Hi there! I need some help with my order please.",
        "Hello, I'm having trouble with my game development project and could use some assistance.",
        "Hi! Can you help me track my order? I haven't received any updates.",
        "Hello, I have a question about my recent purchase.",
        "Hi there! I'm looking for support with my project timeline.",
        "Hey, I'm a bit confused about the status of my order.",
        "Hello! I need help understanding what's going on with my project."
      ];
      
      const randomMessage = initialMessages[Math.floor(Math.random() * initialMessages.length)];
      
      await this.createMessage({
        conversationId: conversation.id,
        senderType: "customer",
        content: randomMessage,
      });
    }

    return conversation;
  }

  async completeConversation(conversationId: number, rating?: number, review?: string, wasAbandoned = false): Promise<Conversation | undefined> {
    // Only award earnings if conversation was completed successfully by satisfied AI customer
    const baseEarnings = 0.25;
    const starBonus = rating ? rating * 0.20 : 0;
    const totalEarnings = wasAbandoned ? 0 : (baseEarnings + starBonus);

    const [conversation] = await db
      .update(conversations)
      .set({
        status: "completed",
        completedAt: new Date(),
        customerRating: rating,
        customerReview: review,
        earnings: totalEarnings.toString(),
        wasAbandoned,
      })
      .where(eq(conversations.id, conversationId))
      .returning();

    if (conversation && conversation.employeeId && !wasAbandoned) {
      // Only create earnings record if customer was satisfied (not abandoned)
      await this.createEarning({
        employeeId: conversation.employeeId,
        conversationId: conversation.id,
        amount: totalEarnings.toString(),
        type: "star_bonus",
        description: `${rating} star rating - customer satisfied`,
      });

      // Log chat completion activity
      await this.logActivity(conversation.employeeId, 'CHAT_COMPLETED', 
        `Chat completed with ${rating} star rating - earned $${totalEarnings}`, {
        conversationId: conversation.id,
        chatNumber: conversation.chatNumber,
        rating: rating,
        review: review,
        earnings: totalEarnings,
        wasAbandoned: false,
        completedAt: conversation.completedAt,
      });
    } else if (conversation && conversation.employeeId && wasAbandoned) {
      // Log abandonment - no earnings awarded
      await this.logActivity(conversation.employeeId, 'CHAT_ABANDONED', 
        'Customer left chat - no earnings awarded', {
        conversationId: conversation.id,
        chatNumber: conversation.chatNumber,
        earnings: 0,
        wasAbandoned: true,
        completedAt: conversation.completedAt,
      });
    }

    return conversation;
  }

  async updateConversationStartTime(conversationId: number, startTime: Date): Promise<void> {
    await db
      .update(conversations)
      .set({ startedAt: startTime })
      .where(eq(conversations.id, conversationId));
  }

  async getRecentConversationsForEmployee(employeeId: number, limit = 10): Promise<(Conversation & { aiCustomer: AiCustomer })[]> {
    return await db
      .select({
        id: conversations.id,
        employeeId: conversations.employeeId,
        aiCustomerId: conversations.aiCustomerId,
        chatNumber: conversations.chatNumber,
        status: conversations.status,
        issuePreview: conversations.issuePreview,
        startedAt: conversations.startedAt,
        completedAt: conversations.completedAt,
        totalMinutes: conversations.totalMinutes,
        customerRating: conversations.customerRating,
        customerReview: conversations.customerReview,
        earnings: conversations.earnings,
        wasAbandoned: conversations.wasAbandoned,
        aiCustomer: aiCustomers,
      })
      .from(conversations)
      .innerJoin(aiCustomers, eq(conversations.aiCustomerId, aiCustomers.id))
      .where(eq(conversations.employeeId, employeeId))
      .orderBy(desc(conversations.completedAt))
      .limit(limit);
  }

  // Message operations
  async createMessage(messageData: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(messageData)
      .returning();
    return message;
  }

  async getMessagesForConversation(conversationId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.timestamp);
  }

  // Earnings operations
  async createEarning(earningData: InsertEarnings): Promise<Earnings> {
    const [earning] = await db
      .insert(earnings)
      .values(earningData)
      .returning();
    return earning;
  }

  async getTodayEarningsForEmployee(employeeId: number): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const result = await db
      .select({ total: sum(earnings.amount) })
      .from(earnings)
      .where(and(
        eq(earnings.employeeId, employeeId),
        eq(earnings.earnedAt, today)
      ));
    
    return Number(result[0]?.total || 0);
  }

  async getEarningsBreakdownForEmployee(employeeId: number, limit = 10): Promise<(Earnings & { conversation?: Conversation })[]> {
    const results = await db
      .select({
        id: earnings.id,
        employeeId: earnings.employeeId,
        conversationId: earnings.conversationId,
        amount: earnings.amount,
        type: earnings.type,
        description: earnings.description,
        earnedAt: earnings.earnedAt,
        conversation: conversations,
      })
      .from(earnings)
      .leftJoin(conversations, eq(earnings.conversationId, conversations.id))
      .where(eq(earnings.employeeId, employeeId))
      .orderBy(desc(earnings.earnedAt))
      .limit(limit);

    return results.map(result => ({
      id: result.id,
      employeeId: result.employeeId,
      conversationId: result.conversationId,
      amount: result.amount,
      type: result.type,
      description: result.description,
      earnedAt: result.earnedAt,
      conversation: result.conversation || undefined,
    }));
  }

  async getEmployeeStats(employeeId: number): Promise<{
    todayEarnings: number;
    todayConversations: number;
    averageRating: number;
    totalEarnings: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const [earningsResult] = await db
      .select({ 
        todayTotal: sum(earnings.amount),
        totalEarnings: sum(earnings.amount)
      })
      .from(earnings)
      .where(eq(earnings.employeeId, employeeId));

    const [conversationsResult] = await db
      .select({ 
        todayCount: count(),
        avgRating: avg(conversations.customerRating)
      })
      .from(conversations)
      .where(and(
        eq(conversations.employeeId, employeeId),
        eq(conversations.status, "completed")
      ));

    return {
      todayEarnings: Number(earningsResult?.todayTotal || 0),
      todayConversations: conversationsResult?.todayCount || 0,
      averageRating: Number(conversationsResult?.avgRating || 0),
      totalEarnings: Number(earningsResult?.totalEarnings || 0),
    };
  }

  async getAllEmployeeStats(): Promise<{
    totalEmployees: number;
    activeEmployees: number;
    totalConversations: number;
    averageRating: number;
    totalEarnings: number;
  }> {
    const [employeeStats] = await db
      .select({ 
        total: count(),
        active: count(employees.isActive)
      })
      .from(employees);

    const [conversationStats] = await db
      .select({ 
        total: count(),
        avgRating: avg(conversations.customerRating)
      })
      .from(conversations)
      .where(eq(conversations.status, "completed"));

    const [earningsStats] = await db
      .select({ total: sum(earnings.amount) })
      .from(earnings);

    return {
      totalEmployees: employeeStats?.total || 0,
      activeEmployees: employeeStats?.active || 0,
      totalConversations: conversationStats?.total || 0,
      averageRating: Number(conversationStats?.avgRating || 0),
      totalEarnings: Number(earningsStats?.total || 0),
    };
  }

  // Activity logging operations
  async logActivity(employeeId: number, activityType: string, description: string, metadata?: any): Promise<ActivityLog> {
    const [log] = await db
      .insert(activityLogs)
      .values({
        employeeId,
        activityType,
        description,
        metadata: metadata ? JSON.stringify(metadata) : null,
      })
      .returning();
    return log;
  }

  async getActivityLogsForEmployee(employeeId: number, limit = 50): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.employeeId, employeeId))
      .orderBy(desc(activityLogs.timestamp))
      .limit(limit);
  }

  async getActivityLogsForSession(employeeId: number, sessionId: number): Promise<ActivityLog[]> {
    // Get all activity logs for the employee during the session timeframe
    const session = await db
      .select()
      .from(workSessions)
      .where(eq(workSessions.id, sessionId))
      .limit(1);

    if (!session[0]) return [];

    const sessionStart = session[0].clockInTime;
    const sessionEnd = session[0].clockOutTime || new Date();

    return await db
      .select()
      .from(activityLogs)
      .where(
        and(
          eq(activityLogs.employeeId, employeeId),
          // Filter by timestamp range for the session
        )
      )
      .orderBy(desc(activityLogs.timestamp));
  }
}

export const storage = new DatabaseStorage();
